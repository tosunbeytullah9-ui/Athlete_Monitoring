@echo off
title Exercise Library
echo.
echo  Exercise Library — Starting...
echo.

:: Change to the directory where this bat file lives
cd /d "%~dp0"

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo  ERROR: Python not found.
    echo  Install Python 3.10+ from https://www.python.org/downloads/
    pause
    exit /b 1
)

:: Install dependencies if not present
python -c "import fastapi" >nul 2>&1
if errorlevel 1 (
    echo  Installing dependencies...
    pip install -r requirements.txt
    echo.
)

:: Open browser after a short delay (runs in background)
timeout /t 2 >nul
start "" "http://localhost:8000"

:: Run the app
echo  Open your browser at: http://localhost:8000
echo  Press Ctrl+C to stop.
echo.
python -m uvicorn main:app --host 127.0.0.1 --port 8000

pause
