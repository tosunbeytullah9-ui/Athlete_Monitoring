/* ═══════════════════════════════════════════════════════════════════════════
   Movement Pattern Colour Map
   Based on the evidence-based taxonomy:
     Lower body  — warm palette (orange / amber / yellow)
     Upper body  — cool palette (blue / indigo / green / teal)
     Core        — red / pink / rose / purple spectrum
     Power/Speed — cyan / sky
     Gymnastics  — green spectrum
     Mobility    — neutral grey
   ═══════════════════════════════════════════════════════════════════════════ */
const PATTERN_COLORS = {
  // ── Upper Body Push ──────────────────────────────────────────────
  "Push – Horizontal":           "#3B82F6",   // blue-500
  "Push – Vertical":             "#6366F1",   // indigo-500

  // ── Upper Body Pull ──────────────────────────────────────────────
  "Pull – Horizontal":           "#10B981",   // emerald-500
  "Pull – Vertical":             "#0D9488",   // teal-600

  // ── Lower Body Hinge (Hip-Dominant) ─────────────────────────────
  "Hinge – Bilateral":           "#F97316",   // orange-500
  "Hinge – Unilateral":          "#EA580C",   // orange-600

  // ── Lower Body Squat (Knee-Dominant) ────────────────────────────
  "Squat – Bilateral":           "#D97706",   // amber-600
  "Squat – Unilateral":          "#B45309",   // amber-700

  // ── Loaded Carry ─────────────────────────────────────────────────
  "Loaded Carry":                "#65A30D",   // lime-600

  // ── Core (McGill sub-taxonomy) ───────────────────────────────────
  "Core – Anti-Extension":       "#EF4444",   // red-500
  "Core – Anti-Rotation":        "#EC4899",   // pink-500
  "Core – Anti-Lateral Flexion": "#F43F5E",   // rose-500
  "Core – Rotation":             "#A855F7",   // purple-500

  // ── Speed / Power ────────────────────────────────────────────────
  "Olympic Lifting":             "#0EA5E9",   // sky-500
  "Linear Speed & Acceleration": "#06B6D4",   // cyan-500
  "Change of Direction":         "#0891B2",   // cyan-600

  // ── Gymnastics-Specific ──────────────────────────────────────────
  "Straight-Arm Strength":       "#059669",   // emerald-600
  "Bent-Arm Gymnastics":         "#047857",   // emerald-700

  // ── Mobility ─────────────────────────────────────────────────────
  "Mobility / Flexibility":      "#6B7280",   // gray-500
};

const QUALITY_COLORS = {
  "Strength":             { bg: "#F1F5F9", text: "#475569" },
  "Power":                { bg: "#FEF3C7", text: "#B45309" },
  "Plyometric / Reactive":{ bg: "#EDE9FE", text: "#6D28D9" },
  "Speed / Agility":      { bg: "#ECFDF5", text: "#065F46" },
  "Mobility":             { bg: "#F0FDF4", text: "#166534" },
};

function patternColor(p) {
  if (PATTERN_COLORS[p]) return PATTERN_COLORS[p];
  const custom = (state.customPatterns || []).find(c => c.name === p);
  return custom?.color || "#4A7CF6";
}
function qualityStyle(q) { return QUALITY_COLORS[q] || { bg: "#F1F5F9", text: "#475569" }; }

/* ── State ────────────────────────────────────────────────────────────────── */
const state = {
  exercises: [],
  patterns:  [],
  filters: {
    search:          "",
    pattern:         "",
    difficulty:      "",
    training_quality:"",
    sport:           "",
    gender:          "",
  },
  editingId:        null,
  currentUser:      null,
  token:            null,
  athletes:         [],
  currentAthleteId: null,
};

/* ── DOM refs ─────────────────────────────────────────────────────────────── */
const $  = id => document.getElementById(id);
const grid          = $("exerciseGrid");
const emptyState    = $("emptyState");
const patternFilters= $("patternFilters");
const exerciseCount = $("exerciseCount");
const activeFilters = $("activeFilters");
const searchInput   = $("searchInput");
const clearSearch   = $("clearSearch");

/* ── API ──────────────────────────────────────────────────────────────────── */
async function apiFetch(path, opts = {}) {
  const headers = { "Content-Type": "application/json" };
  if (state.token) headers["Authorization"] = `Bearer ${state.token}`;
  const res = await fetch(path, { headers, ...opts });
  if (res.status === 401) {
    logout();
    throw new Error("Session expired. Please sign in again.");
  }
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(err.detail || "Request failed");
  }
  if (res.status === 204) return null;
  return res.json();
}

async function loadExercises() {
  const params = new URLSearchParams();
  if (state.filters.search)          params.set("search",           state.filters.search);
  if (state.filters.pattern)         params.set("movement_pattern", state.filters.pattern);
  if (state.filters.difficulty)      params.set("difficulty",       state.filters.difficulty);
  if (state.filters.training_quality)params.set("training_quality", state.filters.training_quality);
  if (state.filters.sport)           params.set("sport_tag",        state.filters.sport);
  if (state.filters.gender)          params.set("gender_tag",       state.filters.gender);
  state.exercises = await apiFetch(`/api/exercises?${params}`);
  renderGrid();
}

async function loadMeta() {
  const meta = await apiFetch("/api/meta");
  state.patterns       = meta.movement_patterns;
  state.customPatterns = meta.custom_patterns || [];
  renderPatternFilters();
}

/* ── Render Grid ──────────────────────────────────────────────────────────── */
function renderGrid() {
  grid.innerHTML = "";
  exerciseCount.textContent = `${state.exercises.length} exercise${state.exercises.length !== 1 ? "s" : ""}`;

  if (state.exercises.length === 0) {
    emptyState.classList.remove("hidden");
    return;
  }
  emptyState.classList.add("hidden");

  state.exercises.forEach(ex => {
    const card = document.createElement("div");
    card.className = "exercise-card";
    const qs = qualityStyle(ex.training_quality);
    card.innerHTML = `
      <div class="card-header">
        <div class="card-names">
          <div class="card-name">${esc(ex.name)}</div>
          ${ex.name_tr ? `<div class="card-name-tr">${esc(ex.name_tr)}</div>` : ""}
        </div>
        <div class="difficulty-badge diff-${ex.difficulty}">${esc(ex.difficulty)}</div>
      </div>
      <div class="card-pattern-chip" style="background:${patternColor(ex.movement_pattern)}">
        <span class="dot"></span>${esc(ex.movement_pattern)}
      </div>
      <div class="card-quality-chip" style="background:${qs.bg};color:${qs.text}">
        ${esc(ex.training_quality || "Strength")}
      </div>
      <div class="card-muscles">
        <strong>Primary:</strong> ${esc((ex.primary_muscles || []).join(", ") || "—")}
      </div>
      <div class="card-footer">
        ${(ex.sport_tags || []).map(t => `<span class="sport-tag sport-${t}">${t}</span>`).join("")}
      </div>
    `;
    card.addEventListener("click", () => openDetailModal(ex));
    grid.appendChild(card);
  });
}

/* ── Render Pattern Filters ───────────────────────────────────────────────── */
function renderPatternFilters() {
  patternFilters.innerHTML = "";

  const allItem = document.createElement("div");
  allItem.className = "pattern-item" + (state.filters.pattern === "" ? " active" : "");
  allItem.innerHTML = `<span class="pattern-dot" style="background:#4A7CF6"></span><span>All Patterns</span>`;
  allItem.addEventListener("click", () => {
    state.filters.pattern = "";
    loadExercises();
    renderPatternFilters();
    renderActiveFilters();
  });
  patternFilters.appendChild(allItem);

  const customNames = new Set((state.customPatterns || []).map(c => c.name));
  const isCoachOrStaff = ["coach", "staff"].includes(state.currentUser?.role);

  state.patterns.forEach(p => {
    const item = document.createElement("div");
    item.className = "pattern-item" + (state.filters.pattern === p ? " active" : "");
    const color = patternColor(p);
    const isCustom = customNames.has(p);
    item.innerHTML = `
      <span class="pattern-dot" style="background:${color}"></span>
      <span style="flex:1">${esc(p)}</span>
      ${isCustom && isCoachOrStaff ? `<button class="pattern-delete-btn" title="Delete category" onclick="deletePattern(event,'${esc(p).replace(/'/g,"\\'")}')"><i class="fa-solid fa-xmark"></i></button>` : ""}
    `;
    item.addEventListener("click", () => {
      state.filters.pattern = (state.filters.pattern === p) ? "" : p;
      loadExercises();
      renderPatternFilters();
      renderActiveFilters();
    });
    patternFilters.appendChild(item);
  });
}

/* ── Category Management ──────────────────────────────────────────────────── */
function openCategoryModal() {
  $("categoryName").value  = "";
  $("categoryColor").value = "#4A7CF6";
  $("categoryModal").classList.remove("hidden");
  $("categoryName").focus();
}

$("categoryModalClose").addEventListener("click", () => $("categoryModal").classList.add("hidden"));
$("addCategoryBtn").addEventListener("click", openCategoryModal);

$("saveCategoryBtn").addEventListener("click", async () => {
  const name  = $("categoryName").value.trim();
  const color = $("categoryColor").value;
  if (!name) { alert("Name is required."); return; }
  try {
    await apiFetch("/api/meta/patterns", { method: "POST", body: JSON.stringify({ name, color }) });
    $("categoryModal").classList.add("hidden");
    await loadMeta();
    populatePatternSelect();
  } catch (err) { alert("Error: " + err.message); }
});

async function deletePattern(e, name) {
  e.stopPropagation();
  if (!confirm(`Delete category "${name}"? This cannot be undone.`)) return;
  try {
    await apiFetch(`/api/meta/patterns/${encodeURIComponent(name)}`, { method: "DELETE" });
    if (state.filters.pattern === name) state.filters.pattern = "";
    await loadMeta();
    populatePatternSelect();
    renderActiveFilters();
  } catch (err) { alert("Error: " + err.message); }
}

/* ── Active Filter Tags ───────────────────────────────────────────────────── */
function renderActiveFilters() {
  activeFilters.innerHTML = "";
  const add = (label, key) => {
    const tag = document.createElement("div");
    tag.className = "filter-tag";
    tag.innerHTML = `${esc(label)} <button title="Remove"><i class="fa-solid fa-xmark"></i></button>`;
    tag.querySelector("button").addEventListener("click", () => {
      state.filters[key] = "";
      if (key === "pattern") renderPatternFilters();
      // reset the corresponding chip UI
      const chipGroups = {
        difficulty: "difficultyFilters",
        training_quality: "qualityFilters",
        sport: "sportFilters",
        gender: "genderFilters",
      };
      if (chipGroups[key]) {
        const container = $(chipGroups[key]);
        container.querySelectorAll(".chip").forEach(c => c.classList.remove("active"));
        container.querySelector(".chip[data-val='']").classList.add("active");
      }
      loadExercises();
      renderActiveFilters();
    });
    activeFilters.appendChild(tag);
  };
  if (state.filters.pattern)         add(`Pattern: ${state.filters.pattern}`, "pattern");
  if (state.filters.training_quality)add(`Quality: ${state.filters.training_quality}`, "training_quality");
  if (state.filters.difficulty)      add(`Difficulty: ${state.filters.difficulty}`, "difficulty");
  if (state.filters.sport)           add(`Sport: ${state.filters.sport}`, "sport");
  if (state.filters.gender)          add(`Gender: ${state.filters.gender}`, "gender");
  if (state.filters.search)          add(`Search: "${state.filters.search}"`, "search");
}

/* ── Detail Modal ─────────────────────────────────────────────────────────── */
function openDetailModal(ex) {
  const modal = $("detailModal");
  const content = $("detailContent");

  const qs = qualityStyle(ex.training_quality);
  const sportTags = (ex.sport_tags || []).map(t => `<span class="sport-tag sport-${t}">${t}</span>`).join(" ");
  const primaryPills = (ex.primary_muscles || []).map(m => `<span class="muscle-pill primary">${esc(m)}</span>`).join("");
  const secondaryPills = (ex.secondary_muscles || []).map(m => `<span class="muscle-pill">${esc(m)}</span>`).join("");
  const cues = (ex.coaching_cues || []).map(c => `<li>${esc(c)}</li>`).join("");
  const equipment = (ex.equipment || []).join(", ") || "—";
  const genderTags = (ex.gender_tags || []).join(", ");

  content.innerHTML = `
    <div class="detail-header">
      <div class="detail-name">${esc(ex.name)}</div>
      ${ex.name_tr ? `<div class="detail-name-tr">${esc(ex.name_tr)}</div>` : ""}
      <div class="detail-meta">
        <div class="card-pattern-chip" style="background:${patternColor(ex.movement_pattern)}">
          <span class="dot"></span>${esc(ex.movement_pattern)}
        </div>
        <div class="card-quality-chip" style="background:${qs.bg};color:${qs.text}">
          ${esc(ex.training_quality || "Strength")}
        </div>
        <div class="difficulty-badge diff-${ex.difficulty}">${esc(ex.difficulty)}</div>
        ${sportTags}
      </div>
    </div>

    ${ex.description ? `
    <div class="detail-section">
      <div class="detail-section-label">Description</div>
      <p>${esc(ex.description)}</p>
    </div>` : ""}

    <div class="detail-section">
      <div class="detail-section-label">Muscles</div>
      ${primaryPills ? `<div class="muscle-pills" style="margin-bottom:6px">${primaryPills}</div>` : ""}
      ${secondaryPills ? `<div class="muscle-pills">${secondaryPills}</div>` : ""}
    </div>

    ${cues ? `
    <div class="detail-section">
      <div class="detail-section-label">Coaching Cues</div>
      <ul class="cue-list">${cues}</ul>
    </div>` : ""}

    <div class="detail-section">
      <div class="detail-section-label">Details</div>
      <p style="font-size:0.84rem; color:#6B7280">
        <strong>Equipment:</strong> ${esc(equipment)}&nbsp;&nbsp;
        <strong>Category:</strong> ${esc(ex.category || "—")}&nbsp;&nbsp;
        <strong>Gender:</strong> ${esc(genderTags)}
      </p>
    </div>

    ${ex.notes ? `
    <div class="detail-section">
      <div class="detail-section-label">Notes</div>
      <p style="font-style:italic; color:#6B7280">${esc(ex.notes)}</p>
    </div>` : ""}

    ${ex.video_url ? `
    <div class="detail-section">
      <div class="detail-section-label">Video</div>
      <a href="${esc(ex.video_url)}" target="_blank" rel="noopener" style="color:#4A7CF6;font-size:0.88rem">
        <i class="fa-solid fa-play-circle"></i> Watch video
      </a>
    </div>` : ""}
  `;

  $("detailEdit").onclick   = () => { closeModal("detailModal"); openFormModal(ex); };
  $("detailDelete").onclick = () => confirmDelete(ex);
  modal.classList.remove("hidden");
}

/* ── Form Modal ───────────────────────────────────────────────────────────── */
const PATTERNS_DEFAULT = Object.keys(PATTERN_COLORS);

function populatePatternSelect() {
  const sel = $("f-pattern");
  sel.innerHTML = "";
  const allPatterns = [...new Set([...PATTERNS_DEFAULT, ...state.patterns])];
  allPatterns.forEach(p => {
    const opt = document.createElement("option");
    opt.value = p;
    opt.textContent = p;
    sel.appendChild(opt);
  });
}

function openFormModal(ex = null) {
  state.editingId = ex ? ex.id : null;
  $("formTitle").textContent = ex ? "Edit Exercise" : "Add Exercise";
  populatePatternSelect();

  $("f-name").value       = ex?.name        || "";
  $("f-name-tr").value    = ex?.name_tr     || "";
  $("f-pattern").value    = ex?.movement_pattern || PATTERNS_DEFAULT[0];
  $("f-quality").value    = ex?.training_quality || "Strength";
  $("f-category").value   = ex?.category    || "";
  $("f-difficulty").value = ex?.difficulty  || "Intermediate";
  $("f-equipment").value  = (ex?.equipment  || []).join(", ");
  $("f-primary").value    = (ex?.primary_muscles   || []).join(", ");
  $("f-secondary").value  = (ex?.secondary_muscles || []).join(", ");
  $("f-description").value= ex?.description || "";
  $("f-cues").value       = (ex?.coaching_cues || []).join("\n");
  $("f-sport").value      = (ex?.sport_tags  || []).join(", ");
  $("f-gender").value     = (ex?.gender_tags || ["all"]).join(", ");
  $("f-video").value      = ex?.video_url   || "";
  $("f-notes").value      = ex?.notes       || "";

  $("formModal").classList.remove("hidden");
  $("f-name").focus();
}

$("exerciseForm").addEventListener("submit", async e => {
  e.preventDefault();
  const splitComma = v => v.split(",").map(s => s.trim()).filter(Boolean);
  const splitLine  = v => v.split("\n").map(s => s.trim()).filter(Boolean);

  const payload = {
    name:              $("f-name").value.trim(),
    name_tr:           $("f-name-tr").value.trim() || null,
    movement_pattern:  $("f-pattern").value,
    training_quality:  $("f-quality").value,
    category:          $("f-category").value.trim() || null,
    difficulty:        $("f-difficulty").value,
    equipment:         splitComma($("f-equipment").value),
    primary_muscles:   splitComma($("f-primary").value),
    secondary_muscles: splitComma($("f-secondary").value),
    description:       $("f-description").value.trim() || null,
    coaching_cues:     splitLine($("f-cues").value),
    sport_tags:        splitComma($("f-sport").value),
    gender_tags:       splitComma($("f-gender").value) || ["all"],
    video_url:         $("f-video").value.trim() || null,
    notes:             $("f-notes").value.trim() || null,
  };

  try {
    if (state.editingId) {
      await apiFetch(`/api/exercises/${state.editingId}`, { method: "PUT", body: JSON.stringify(payload) });
    } else {
      await apiFetch("/api/exercises", { method: "POST", body: JSON.stringify(payload) });
    }
    closeModal("formModal");
    await loadMeta();
    await loadExercises();
  } catch (err) {
    alert("Error: " + err.message);
  }
});

/* ── Delete ───────────────────────────────────────────────────────────────── */
function confirmDelete(ex) {
  $("confirmMsg").textContent = `Delete "${ex.name}"? This cannot be undone.`;
  $("confirmModal").classList.remove("hidden");

  $("confirmYes").onclick = async () => {
    try {
      await apiFetch(`/api/exercises/${ex.id}`, { method: "DELETE" });
      closeModal("confirmModal");
      closeModal("detailModal");
      await loadMeta();
      await loadExercises();
    } catch (err) {
      alert("Error: " + err.message);
    }
  };
}

/* ── Modal helpers ────────────────────────────────────────────────────────── */
function closeModal(id) { $(id).classList.add("hidden"); }

$("detailClose").onclick = () => closeModal("detailModal");
$("formClose").onclick   = () => closeModal("formModal");
$("formCancel").onclick  = () => closeModal("formModal");
$("confirmNo").onclick   = () => closeModal("confirmModal");
$("resetFiltersBtn").onclick = resetAll;

["detailModal","formModal","confirmModal"].forEach(id => {
  $(id).addEventListener("click", e => { if (e.target === $(id)) closeModal(id); });
});

/* ── Sidebar toggle ───────────────────────────────────────────────────────── */
$("sidebarToggle").addEventListener("click", () => {
  $("sidebar").classList.toggle("collapsed");
});

/* ── Search ───────────────────────────────────────────────────────────────── */
let searchTimer;
searchInput.addEventListener("input", e => {
  clearTimeout(searchTimer);
  const val = e.target.value.trim();
  clearSearch.classList.toggle("visible", val.length > 0);
  searchTimer = setTimeout(() => {
    state.filters.search = val;
    loadExercises();
    renderActiveFilters();
  }, 300);
});
clearSearch.addEventListener("click", () => {
  searchInput.value = "";
  clearSearch.classList.remove("visible");
  state.filters.search = "";
  loadExercises();
  renderActiveFilters();
});

/* ── Chip filter wiring ───────────────────────────────────────────────────── */
function setupChips(containerId, stateKey) {
  $(containerId).addEventListener("click", e => {
    const chip = e.target.closest(".chip");
    if (!chip) return;
    $(containerId).querySelectorAll(".chip").forEach(c => c.classList.remove("active"));
    chip.classList.add("active");
    state.filters[stateKey] = chip.dataset.val;
    loadExercises();
    renderActiveFilters();
  });
}
setupChips("qualityFilters",     "training_quality");
setupChips("difficultyFilters",  "difficulty");
setupChips("sportFilters",       "sport");
setupChips("genderFilters",      "gender");

/* ── Add button ───────────────────────────────────────────────────────────── */
$("addExerciseBtn").addEventListener("click", () => openFormModal());

/* ── Reset all ────────────────────────────────────────────────────────────── */
function resetAll() {
  Object.keys(state.filters).forEach(k => state.filters[k] = "");
  searchInput.value = "";
  clearSearch.classList.remove("visible");
  document.querySelectorAll(".chip").forEach(c => c.classList.remove("active"));
  document.querySelectorAll(".chip[data-val='']").forEach(c => c.classList.add("active"));
  renderPatternFilters();
  loadExercises();
  renderActiveFilters();
}

/* ── Escape HTML ──────────────────────────────────────────────────────────── */
function esc(str) {
  if (str == null) return "";
  return String(str)
    .replace(/&/g,"&amp;").replace(/</g,"&lt;")
    .replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}

/* ── Keyboard shortcuts ───────────────────────────────────────────────────── */
document.addEventListener("keydown", e => {
  if (e.key === "Escape") {
    ["detailModal","formModal","confirmModal"].forEach(id => closeModal(id));
  }
  if ((e.ctrlKey || e.metaKey) && e.key === "k") {
    e.preventDefault();
    searchInput.focus();
    searchInput.select();
  }
});

/* ── Auth ─────────────────────────────────────────────────────────────────── */
function logout() {
  state.token       = null;
  state.currentUser = null;
  $("loginOverlay").classList.remove("hidden");
  $("loginError").classList.add("hidden");
  $("loginUsername").value = "";
  $("loginPassword").value = "";
  $("loginUsername").focus();
}

function applyRoleUI() {
  const role           = state.currentUser?.role;
  const isCoach        = role === "coach";
  const isCoachOrStaff = role === "coach" || role === "staff";
  $("userLabel").textContent = `${state.currentUser?.username} · ${role}`;

  // User management: coach only
  $("usersBtn").classList.toggle("hidden", !isCoach);
  // Full UI: coach and staff
  $("tabLibrary").classList.toggle("hidden", !isCoachOrStaff);
  $("tabAthletes").classList.toggle("hidden", !isCoachOrStaff);
  $("tabTeams").classList.toggle("hidden", !isCoachOrStaff);
  $("addExerciseBtn").classList.toggle("hidden", !isCoachOrStaff);
  $("addCategoryBtn").classList.toggle("hidden", !isCoachOrStaff);

  // Apply athlete-mode CSS class for hiding edit controls in rendered HTML
  document.body.classList.toggle("athlete-mode", !isCoachOrStaff);
}

async function checkAuth() {
  localStorage.removeItem("auth_token");   // clear any stale saved session
  $("loginOverlay").classList.remove("hidden");
  $("loginUsername").focus();
}

async function startApp() {
  $("loginOverlay").classList.add("hidden");
  applyRoleUI();
  if (state.currentUser.role === "coach" || state.currentUser.role === "staff") {
    await loadMeta();
    await loadExercises();
    switchView("library");
  } else {
    switchView("programs");
  }
  initPrograms();
}

$("loginBtn").addEventListener("click", doLogin);
$("loginPassword").addEventListener("keydown", e => { if (e.key === "Enter") doLogin(); });
$("loginUsername").addEventListener("keydown", e => { if (e.key === "Enter") $("loginPassword").focus(); });

async function doLogin() {
  const username = $("loginUsername").value.trim();
  const password = $("loginPassword").value;
  if (!username || !password) return;
  $("loginBtn").disabled = true;
  try {
    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      $("loginError").textContent = err.detail || "Invalid username or password";
      $("loginError").classList.remove("hidden");
      $("loginPassword").value = "";
      $("loginPassword").focus();
      return;
    }
    const data = await res.json();
    state.token       = data.token;
    state.currentUser = data.user;
    $("loginError").classList.add("hidden");
    await startApp();
  } catch (err) {
    $("loginError").textContent = "Connection error. Is the server running?";
    $("loginError").classList.remove("hidden");
  } finally {
    $("loginBtn").disabled = false;
  }
}

$("logoutBtn").addEventListener("click", logout);

/* ── User management ──────────────────────────────────────────────────────── */
$("usersBtn").addEventListener("click", openUsersModal);
$("usersModalClose").addEventListener("click", () => closeModal("usersModal"));
$("usersModal").addEventListener("click", e => { if (e.target === $("usersModal")) closeModal("usersModal"); });

// Role chip selector in users modal
$("newUserRoleChips").addEventListener("click", e => {
  const chip = e.target.closest(".chip");
  if (!chip) return;
  $("newUserRoleChips").querySelectorAll(".chip").forEach(c => c.classList.remove("active"));
  chip.classList.add("active");
});

async function openUsersModal() {
  await loadUsersList();
  $("newUserUsername").value = "";
  $("newUserPassword").value = "";
  $("usersModal").classList.remove("hidden");
}

async function loadUsersList() {
  const users = await apiFetch("/api/users");
  const list  = $("usersList");
  list.innerHTML = "";
  users.forEach(u => {
    const row = document.createElement("div");
    row.className = "user-row";
    const isSelf = u.id === state.currentUser?.id;
    row.innerHTML = `
      <div class="user-row-info">
        <span class="user-row-name">${esc(u.username)}</span>
        <span class="user-role-badge role-${u.role}">${u.role}</span>
        ${isSelf ? '<span style="font-size:.75rem;color:#9CA3AF">(you)</span>' : ""}
      </div>
      <div class="user-row-actions">
        ${!isSelf ? `<button class="btn-danger btn-sm" onclick="deleteUser(${u.id}, '${esc(u.username)}')"><i class="fa-solid fa-trash"></i></button>` : ""}
      </div>
    `;
    list.appendChild(row);
  });
}

async function deleteUser(uid, name) {
  if (!confirm(`Delete user "${name}"? This cannot be undone.`)) return;
  try {
    await apiFetch(`/api/users/${uid}`, { method: "DELETE" });
    await loadUsersList();
  } catch (err) { alert("Error: " + err.message); }
}

$("addUserBtn").addEventListener("click", async () => {
  const username = $("newUserUsername").value.trim();
  const password = $("newUserPassword").value;
  const role     = $("newUserRoleChips").querySelector(".chip.active")?.dataset.val || "athlete";
  if (!username || !password) { alert("Username and password are required."); return; }
  try {
    await apiFetch("/api/users", { method: "POST", body: JSON.stringify({ username, password, role }) });
    $("newUserUsername").value = "";
    $("newUserPassword").value = "";
    await loadUsersList();
  } catch (err) { alert("Error: " + err.message); }
});

/* ── Init ─────────────────────────────────────────────────────────────────── */
(async function init() {
  await checkAuth();
})();

/* ═══════════════════════════════════════════════════════════════════════════
   PROGRAMS FEATURE
   ═══════════════════════════════════════════════════════════════════════════ */

/* ── Constants ────────────────────────────────────────────────────────────── */
const PHASE_COLORS = {
  accumulation:    "#3B82F6",
  intensification: "#F97316",
  realization:     "#EF4444",
  deload:          "#22C55E",
};

const PHASE_LABELS = {
  accumulation:    "Accum",
  intensification: "Intens",
  realization:     "Real",
  deload:          "Deload",
};

const GOAL_DEFAULTS = {
  strength:    { sets: 4, reps: "4",     intensity_type: "pct_1rm", intensity_value: "80", rest_seconds: 180 },
  hypertrophy: { sets: 4, reps: "8-10",  intensity_type: "rpe",     intensity_value: "8",  rest_seconds: 90  },
  power:       { sets: 4, reps: "3",     intensity_type: "pct_1rm", intensity_value: "75", rest_seconds: 150 },
  endurance:   { sets: 3, reps: "15-20", intensity_type: "rpe",     intensity_value: "7",  rest_seconds: 60  },
  mixed:       { sets: 3, reps: "8",     intensity_type: "rpe",     intensity_value: "8",  rest_seconds: 120 },
};

/* ── Program state ────────────────────────────────────────────────────────── */
const pState = {
  programs:            [],
  currentProgram:      null,
  activeWeekNum:       1,
  sexSessionId:        null,    // session being edited in the exercise modal
  sexEditId:           null,    // session-exercise id when editing (null = new)
  sexSelectedEx:       null,    // { id, name } selected from search
  oneRMMap:            {},      // exercise_id → weight_kg (float), loaded when editor opens
  contextAthleteId:    null,    // athlete id when creating program from athlete detail
  contextAthleteName:  null,    // athlete name for modal title display
  fromAthleteId:       null,    // athlete id to return to after leaving program editor
  contextTeamId:       null,
  contextTeamName:     null,
  fromTeamId:          null,
  teamMembers:         [],
  teamContextAthleteId: null,
  apvWeekNum:          1,
  apvDayNum:           1,
};

/* ── View switcher ────────────────────────────────────────────────────────── */
function switchView(view) {
  const isLib      = view === "library";
  const isProg     = view === "programs";
  const isORM      = view === "one-rm";
  const isAthletes = view === "athletes";
  const isAthDet   = view === "athlete-detail";
  const isTeams    = view === "teams";
  const isTeamDet  = view === "team-detail";

  $("libraryView").classList.toggle("hidden", !isLib);
  $("sidebar").classList.toggle("hidden", !isLib);
  $("sidebarToggle").classList.toggle("hidden", !isLib);
  $("librarySearchBox").classList.toggle("hidden", !isLib);
  $("programsView").classList.toggle("hidden", !isProg);
  $("oneRMView").classList.toggle("hidden", !isORM);
  $("athletesView").classList.toggle("hidden", !isAthletes);
  $("athleteDetailView").classList.toggle("hidden", !isAthDet);
  $("teamsView").classList.toggle("hidden", !isTeams);
  $("teamDetailView").classList.toggle("hidden", !isTeamDet);

  const isCoachOrStaff = ["coach", "staff"].includes(state.currentUser?.role);
  $("addExerciseBtn").classList.toggle("hidden", !isLib);
  $("newProgramBtn").classList.toggle("hidden", !isProg);
  $("addOneRMBtn").classList.toggle("hidden", !isORM || !isCoachOrStaff);

  $("tabLibrary").classList.toggle("active", isLib);
  $("tabPrograms").classList.toggle("active", isProg);
  $("tabOneRM").classList.toggle("active", isORM);
  $("tabAthletes").classList.toggle("active", isAthletes || isAthDet);
  $("tabTeams").classList.toggle("active", isTeams || isTeamDet);

  if (isProg) loadPrograms();
  if (isORM)  loadOneRM();
  if (isAthletes) loadAthletes();
  if (isTeams) loadTeams();
}

$("tabLibrary").addEventListener("click",  () => switchView("library"));
$("tabPrograms").addEventListener("click", () => switchView("programs"));
$("tabOneRM").addEventListener("click",    () => switchView("one-rm"));
$("tabAthletes").addEventListener("click", () => switchView("athletes"));
$("tabTeams").addEventListener("click",    () => switchView("teams"));
$("newProgramBtn").addEventListener("click", openNewProgramModal);
$("addOneRMBtn").addEventListener("click", () => openOneRMModal());

/* ── Load & render program cards ──────────────────────────────────────────── */
async function loadPrograms() {
  pState.programs = await apiFetch("/api/programs");
  renderProgramCards();
}

function renderProgramCards() {
  const grid = $("programsGrid");
  const empty = $("programsEmpty");
  const list = $("programsList");
  const editor = $("programEditor");

  editor.classList.add("hidden");
  $("athleteProgramView").classList.add("hidden");
  list.classList.remove("hidden");
  grid.innerHTML = "";

  if (pState.programs.length === 0) {
    empty.classList.remove("hidden");
    return;
  }
  empty.classList.add("hidden");

  pState.programs.forEach(p => {
    const card = document.createElement("div");
    card.className = "program-card";

    const goalCls = `goal-${p.goal}`;
    const phasesBar = (p.phases || []).map(ph =>
      `<div class="phase-bar-segment" style="background:${PHASE_COLORS[ph] || '#CBD5E1'}" title="${ph}"></div>`
    ).join("");

    const levelLabel = p.athlete_level
      ? `<span class="program-badge">${esc(p.athlete_level)}</span>` : "";
    const sportLabel = p.sport
      ? `<span class="program-badge">${esc(p.sport)}</span>` : "";
    const startLabel = p.start_date
      ? `<span>From ${esc(p.start_date)}</span>` : `<span>No start date</span>`;
    const teamLabel = p.team_id
      ? `<span class="program-badge" style="background:#EFF6FF;color:#1D4ED8"><i class="fa-solid fa-people-group" style="margin-right:3px"></i>Team</span>`
      : (p.athlete_id
        ? `<span class="program-badge" style="background:#F0FDF4;color:#166534"><i class="fa-solid fa-person-running" style="margin-right:3px"></i>Individual</span>`
        : "");

    card.innerHTML = `
      <div class="program-card-name">${esc(p.name)}</div>
      <div class="program-card-meta">
        <span class="program-badge ${goalCls}">${esc(p.goal)}</span>
        <span class="program-badge">${p.duration_weeks}w · ${p.days_per_week}d/wk</span>
        ${levelLabel}
        ${sportLabel}
        ${teamLabel}
      </div>
      <div class="phase-bar">${phasesBar}</div>
      <div class="program-card-footer">
        ${startLabel}
        <div class="program-card-actions">
          <button class="btn-icon edit-prog" title="Edit program"><i class="fa-solid fa-pen"></i></button>
          <button class="btn-icon danger del-prog" title="Delete program"><i class="fa-solid fa-trash"></i></button>
        </div>
      </div>
    `;

    card.addEventListener("click", e => {
      if (e.target.closest(".edit-prog")) { e.stopPropagation(); openNewProgramModal(p); return; }
      if (e.target.closest(".del-prog"))  { e.stopPropagation(); confirmDeleteProgram(p); return; }
      openProgramEditor(p.id);
    });

    grid.appendChild(card);
  });
}

/* ── Program editor ───────────────────────────────────────────────────────── */
async function openProgramEditor(pidOrObj) {
  const pid = (typeof pidOrObj === "object") ? pidOrObj.id : pidOrObj;
  pState.currentProgram = await apiFetch(`/api/programs/${pid}/full`);

  // ── Athlete path: show simplified read-only view ──────────────────────────
  if (document.body.classList.contains("athlete-mode")) {
    pState.apvWeekNum = 1;
    pState.apvDayNum  = 1;
    $("programsList").classList.add("hidden");
    $("athleteProgramView").classList.remove("hidden");
    renderAthleteView();
    return;
  }
  // ─────────────────────────────────────────────────────────────────────────

  pState.activeWeekNum = 1;

  // Pre-load all 1RM records into a fast lookup map (exercise_id → kg)
  const ormRecords = await apiFetch("/api/one-rm").catch(() => []);
  pState.oneRMMap = {};
  ormRecords.forEach(r => {
    if (r.exercise_id) {
      // Keep the most recent record per exercise (API already orders by date desc)
      if (!(r.exercise_id in pState.oneRMMap)) {
        pState.oneRMMap[r.exercise_id] = parseFloat(r.weight_kg);
      }
    }
  });

  // If this is a team program, load team members and clear 1RM map (use athlete context selector instead)
  pState.teamMembers = [];
  pState.teamContextAthleteId = null;
  if (pState.currentProgram.team_id) {
    const isAthlete = state.currentUser?.role === "athlete";
    if (!isAthlete) {
      const team = await apiFetch("/api/teams/" + pState.currentProgram.team_id).catch(() => null);
      if (team) {
        pState.teamMembers = team.members || [];
        pState.oneRMMap = {};  // will be loaded when athlete is selected
      }
    }
    // Athletes keep the oneRMMap already loaded above (their own records)
  }

  $("programsList").classList.add("hidden");
  const editor = $("programEditor");
  editor.classList.remove("hidden");

  renderEditorHeader();
  renderWeekTimeline();
  renderSessionGrid();
}

function renderEditorHeader() {
  const p = pState.currentProgram;
  const goalCls = `goal-${p.goal}`;
  const levelBadge = p.athlete_level
    ? `<span class="program-badge">${esc(p.athlete_level)}</span>` : "";
  const sportBadge = p.sport
    ? `<span class="program-badge">${esc(p.sport)}</span>` : "";
  const teamBadge = p.team_id
    ? `<span class="program-badge" style="background:#EFF6FF;color:#1D4ED8"><i class="fa-solid fa-people-group" style="margin-right:4px"></i>${esc(p.team_name || "Team")}</span>`
    : "";

  let athleteSelector = "";
  if (p.team_id && pState.teamMembers.length > 0) {
    const options = pState.teamMembers.map(a =>
      `<option value="${a.id}" ${pState.teamContextAthleteId === a.id ? "selected" : ""}>${esc(a.name)}</option>`
    ).join("");
    athleteSelector = `
      <div style="display:flex;align-items:center;gap:8px;margin-right:12px">
        <label style="font-size:0.8rem;color:#6B7280;white-space:nowrap">Loads for:</label>
        <select id="teamAthleteCtx" style="padding:5px 8px;border:1.5px solid #E4E7ED;border-radius:8px;font-size:0.85rem;outline:none">
          <option value="">— select athlete —</option>
          ${options}
        </select>
      </div>
    `;
  }

  $("programEditorHeader").innerHTML = `
    <div class="editor-header-left">
      <div class="editor-program-name">${esc(p.name)}</div>
      <div class="editor-program-meta">
        <span class="program-badge ${goalCls}">${esc(p.goal)}</span>
        <span class="program-badge">${p.duration_weeks} weeks</span>
        <span class="program-badge">${p.days_per_week} days/week</span>
        <span class="program-badge">${esc(p.periodization_type)}</span>
        ${levelBadge}${sportBadge}${teamBadge}
      </div>
    </div>
    <div class="editor-header-right">
      ${athleteSelector}
      <button class="btn-ghost" id="editorBackBtn"><i class="fa-solid fa-arrow-left"></i> All Programs</button>
    </div>
  `;
  $("editorBackBtn").addEventListener("click", () => {
    if (pState.fromAthleteId) {
      const aid = pState.fromAthleteId;
      pState.fromAthleteId = null;
      openAthleteDetail(aid);
    } else if (pState.fromTeamId) {
      const tid = pState.fromTeamId;
      pState.fromTeamId = null;
      openTeamDetail(tid);
    } else {
      $("programEditor").classList.add("hidden");
      $("programsList").classList.remove("hidden");
      loadPrograms();
    }
  });

  const ctxSel = $("teamAthleteCtx");
  if (ctxSel) {
    ctxSel.addEventListener("change", async () => {
      const aid = parseInt(ctxSel.value) || null;
      pState.teamContextAthleteId = aid;
      if (aid) {
        const records = await apiFetch("/api/athletes/" + aid + "/one-rm").catch(() => []);
        pState.oneRMMap = {};
        records.forEach(r => {
          if (r.exercise_id && !(r.exercise_id in pState.oneRMMap)) {
            pState.oneRMMap[r.exercise_id] = parseFloat(r.weight_kg);
          }
        });
      } else {
        pState.oneRMMap = {};
      }
      renderSessionGrid();
    });
  }
}

function renderWeekTimeline() {
  const p = pState.currentProgram;
  const tl = $("weekTimeline");
  tl.innerHTML = "";
  (p.weeks || []).forEach(w => {
    const color = PHASE_COLORS[w.phase] || "#CBD5E1";
    const label = PHASE_LABELS[w.phase] || (w.phase || "");
    const isActive = w.week_number === pState.activeWeekNum;
    const block = document.createElement("div");
    block.className = "week-block" + (isActive ? " active" : "");
    block.style.background = color;
    block.innerHTML = `
      <div class="week-block-num">W${w.week_number}</div>
      <div class="week-block-phase">${label}</div>
    `;
    block.title = `Week ${w.week_number}: ${w.phase || "no phase"}`;
    block.addEventListener("click", () => {
      pState.activeWeekNum = w.week_number;
      renderWeekTimeline();
      renderSessionGrid();
    });
    tl.appendChild(block);
  });
}

function renderSessionGrid() {
  const p = pState.currentProgram;
  const week = (p.weeks || []).find(w => w.week_number === pState.activeWeekNum);
  const grid = $("sessionGrid");
  const title = $("sessionGridTitle");

  if (!week) { grid.innerHTML = ""; return; }

  const phaseLabel = week.phase
    ? ` <span style="color:${PHASE_COLORS[week.phase]};font-weight:600">(${week.phase})</span>` : "";
  title.innerHTML = `Week ${week.week_number} Sessions${phaseLabel}`;

  grid.style.setProperty("--days", p.days_per_week);
  grid.innerHTML = "";

  for (let day = 1; day <= p.days_per_week; day++) {
    const col = document.createElement("div");
    col.className = "session-col";
    col.innerHTML = `<div class="session-col-label">Day ${day}</div>`;

    const sessions = (week.sessions || []).filter(s => s.day_number === day);
    sessions.forEach(s => {
      col.appendChild(buildSessionCard(s, week.week_number));
    });

    const addBtn = document.createElement("button");
    addBtn.className = "add-session-btn";
    addBtn.innerHTML = `<i class="fa-solid fa-plus"></i> Add Session`;
    addBtn.addEventListener("click", () => promptAddSession(week.week_number, day));
    col.appendChild(addBtn);

    grid.appendChild(col);
  }
}

function buildSessionCard(session) {
  const card = document.createElement("div");
  card.className = "session-card";

  const exRows = (session.exercises || []).map(e => buildExRow(e)).join("");

  card.innerHTML = `
    <div class="session-card-header">
      <div class="session-card-name">${esc(session.session_name || "Session")}</div>
      <div class="session-card-actions">
        <button class="btn-icon del-session" title="Delete session"><i class="fa-solid fa-trash"></i></button>
      </div>
    </div>
    <div class="ex-list">${exRows}</div>
    <button class="add-ex-btn" style="margin-top:6px">
      <i class="fa-solid fa-plus"></i> Add Exercise
    </button>
  `;

  card.querySelector(".del-session").addEventListener("click", () => confirmDeleteSession(session));
  card.querySelector(".add-ex-btn").addEventListener("click", () => openSessionExModal(session.id, null));
  card.querySelectorAll(".ex-row").forEach((row, i) => {
    row.addEventListener("click", () => openSessionExModal(session.id, session.exercises[i]));
  });

  return card;
}

function buildExRow(ex) {
  const sets = ex.sets || "—";
  const reps = ex.reps || "—";
  const prescription = `${sets}×${reps}`;

  let intensityBadge = "";
  let workingKgBadge = "";

  if (ex.intensity_type && ex.intensity_value) {
    const label = {
      pct_1rm:    `${ex.intensity_value}% 1RM`,
      rpe:        `RPE ${ex.intensity_value}`,
      rir:        `RIR ${ex.intensity_value}`,
      load_kg:    `${ex.intensity_value} kg`,
      bodyweight: "BW",
    }[ex.intensity_type] || ex.intensity_value;
    intensityBadge = `<span class="intensity-badge">${esc(label)}</span>`;

    // Show calculated kg when intensity is %1RM and we have a stored 1RM
    if (ex.intensity_type === "pct_1rm" && ex.exercise_id && ex.exercise_id in pState.oneRMMap) {
      const oneRM      = pState.oneRMMap[ex.exercise_id];
      const pct        = parseFloat(ex.intensity_value);
      const exact      = oneRM * (pct / 100);
      const rounded    = Math.round(exact / 2.5) * 2.5;
      workingKgBadge = `<span class="working-kg-badge" title="1RM: ${oneRM} kg · exact: ${exact.toFixed(1)} kg">${rounded.toFixed(1)} kg</span>`;
    }
  }

  const rest = ex.rest_seconds ? `<span style="font-size:.68rem;color:#9CA3AF">${ex.rest_seconds}s rest</span>` : "";

  const videoLink = ex.video_url
    ? `<a href="${esc(ex.video_url)}" target="_blank" rel="noopener" class="ex-video-link" title="Watch video"><i class="fa-solid fa-circle-play"></i></a>`
    : "";

  return `
    <div class="ex-row">
      <div class="ex-row-name">${esc(ex.exercise_name || "Exercise")}${videoLink}</div>
      <span class="prescription-text">${esc(prescription)}</span>
      ${intensityBadge}
      ${workingKgBadge}
      ${rest}
      <button class="btn-icon danger del-ex" data-id="${ex.id}" title="Remove" style="width:22px;height:22px;flex-shrink:0" onclick="event.stopPropagation();deleteSessionEx(${ex.id})"><i class="fa-solid fa-xmark" style="font-size:.65rem"></i></button>
    </div>
  `;
}

/* ── Athlete simplified program view ─────────────────────────────────────── */
function renderAthleteView() {
  const p = pState.currentProgram;
  $("apvProgramTitle").textContent = p.name;
  const goal  = p.goal ? `<span class="program-badge goal-${esc(p.goal)}">${esc(p.goal)}</span>` : "";
  const weeks = `<span class="program-badge">${p.duration_weeks}w · ${p.days_per_week}d/wk</span>`;
  const level = p.athlete_level ? `<span class="program-badge">${esc(p.athlete_level)}</span>` : "";
  $("apvProgramMeta").innerHTML = [goal, weeks, level].filter(Boolean).join(" ");
  renderApvWeekTabs();
  renderApvDayTabs();
  renderApvExercises();
}

function renderApvWeekTabs() {
  const p    = pState.currentProgram;
  const tabs = $("apvWeekTabs");
  tabs.innerHTML = "";
  (p.weeks || []).forEach(w => {
    const btn = document.createElement("button");
    btn.className = "apv-week-tab" + (w.week_number === pState.apvWeekNum ? " active" : "");
    btn.textContent = `W${w.week_number}`;
    if (w.phase) btn.title = w.phase;
    btn.addEventListener("click", () => {
      pState.apvWeekNum = w.week_number;
      pState.apvDayNum  = 1;
      renderApvWeekTabs();
      renderApvDayTabs();
      renderApvExercises();
    });
    tabs.appendChild(btn);
  });
  $("apvPrevWeek").disabled = pState.apvWeekNum <= 1;
  $("apvNextWeek").disabled = pState.apvWeekNum >= (p.weeks || []).length;
}

function renderApvDayTabs() {
  const p    = pState.currentProgram;
  const week = (p.weeks || []).find(w => w.week_number === pState.apvWeekNum);
  const tabs = $("apvDayTabs");
  tabs.innerHTML = "";
  if (!week) return;
  const days = [...new Set((week.sessions || []).map(s => s.day_number))].sort((a, b) => a - b);
  if (days.length === 0) {
    tabs.innerHTML = `<span class="apv-no-sessions">Bu hafta için antrenman yok.</span>`;
    return;
  }
  if (!days.includes(pState.apvDayNum)) pState.apvDayNum = days[0];
  days.forEach(day => {
    const btn = document.createElement("button");
    btn.className = "apv-day-tab" + (day === pState.apvDayNum ? " active" : "");
    const firstSession = (week.sessions || []).find(s => s.day_number === day);
    btn.textContent = firstSession?.session_name || `Gün ${day}`;
    btn.addEventListener("click", () => {
      pState.apvDayNum = day;
      renderApvDayTabs();
      renderApvExercises();
    });
    tabs.appendChild(btn);
  });
}

function renderApvExercises() {
  const p    = pState.currentProgram;
  const week = (p.weeks || []).find(w => w.week_number === pState.apvWeekNum);
  const list = $("apvExerciseList");
  list.innerHTML = "";
  if (!week) return;
  const sessions = (week.sessions || []).filter(s => s.day_number === pState.apvDayNum);
  if (sessions.length === 0) {
    list.innerHTML = `<div class="apv-empty"><i class="fa-solid fa-dumbbell"></i><p>Bu gün için egzersiz yok.</p></div>`;
    return;
  }
  sessions.forEach(session => {
    if (sessions.length > 1) {
      const heading = document.createElement("div");
      heading.className = "apv-session-heading";
      heading.textContent = session.session_name || "Antrenman";
      list.appendChild(heading);
    }
    (session.exercises || []).forEach((ex, idx) => {
      list.appendChild(buildApvExCard(ex, idx + 1));
    });
  });
}

function buildApvExCard(ex, num) {
  const sets = ex.sets || "—";
  const reps = ex.reps || "—";
  const intensityMap = {
    pct_1rm:    `${ex.intensity_value}% 1RM`,
    rpe:        `RPE ${ex.intensity_value}`,
    rir:        `RIR ${ex.intensity_value}`,
    load_kg:    `${ex.intensity_value} kg`,
    bodyweight: "Vücut Ağırlığı",
  };
  const intensityText = (ex.intensity_type && ex.intensity_value) ? (intensityMap[ex.intensity_type] || esc(ex.intensity_value)) : "";
  const restText = ex.rest_seconds ? `${ex.rest_seconds}sn dinlenme` : "";
  const videoBtn = ex.video_url
    ? `<a href="${esc(ex.video_url)}" target="_blank" rel="noopener" class="apv-video-btn"><i class="fa-solid fa-circle-play"></i> Video</a>`
    : "";
  const card = document.createElement("div");
  card.className = "apv-ex-card";
  card.innerHTML = `
    <div class="apv-ex-num">${num}</div>
    <div class="apv-ex-body">
      <div class="apv-ex-name">${esc(ex.exercise_name || "Egzersiz")}</div>
      <div class="apv-ex-details">
        <span class="apv-ex-sets">${sets}<span class="apv-ex-x">×</span>${reps}</span>
        ${intensityText ? `<span class="apv-ex-intensity">${esc(intensityText)}</span>` : ""}
        ${restText      ? `<span class="apv-ex-rest"><i class="fa-solid fa-clock"></i> ${restText}</span>` : ""}
      </div>
    </div>
    ${videoBtn}
  `;
  return card;
}

/* ── Add session prompt ───────────────────────────────────────────────────── */
/* ── Sync Week 1 day → same day in all other weeks ───────────────────────── */
async function _syncAndRefresh(dayNum) {
  const pid = pState.currentProgram.id;
  if (pState.activeWeekNum === 1 && (pState.currentProgram.duration_weeks || 1) > 1 && dayNum) {
    await apiFetch(`/api/programs/${pid}/sync-week1?day_number=${dayNum}`, { method: "POST" }).catch(() => {});
  }
  pState.currentProgram = await apiFetch(`/api/programs/${pid}/full`);
  renderSessionGrid();
}

function _dayForSession(sid) {
  for (const week of pState.currentProgram.weeks || []) {
    for (const s of week.sessions || []) {
      if (s.id === sid) return s.day_number;
    }
  }
  return null;
}

function _sessionForExercise(seid) {
  for (const week of pState.currentProgram.weeks || []) {
    for (const s of week.sessions || []) {
      if ((s.exercises || []).some(e => e.id === seid)) return s;
    }
  }
  return null;
}

async function promptAddSession(weekNum, dayNum) {
  const name = prompt(`Session name for Week ${weekNum}, Day ${dayNum}:`, "Session") || "Session";
  try {
    await apiFetch(`/api/programs/${pState.currentProgram.id}/sessions`, {
      method: "POST",
      body: JSON.stringify({ week_number: weekNum, day_number: dayNum, session_name: name }),
    });
    await _syncAndRefresh(dayNum);
  } catch (err) { alert("Error: " + err.message); }
}

/* ── Delete session ───────────────────────────────────────────────────────── */
function confirmDeleteSession(session) {
  $("confirmMsg").textContent = `Delete session "${session.session_name || "Session"}" and all its exercises?`;
  $("confirmModal").classList.remove("hidden");
  $("confirmYes").onclick = async () => {
    try {
      await apiFetch(`/api/sessions/${session.id}`, { method: "DELETE" });
      closeModal("confirmModal");
      await _syncAndRefresh(session.day_number);
    } catch (err) { alert("Error: " + err.message); }
  };
}

/* ── Delete session exercise ──────────────────────────────────────────────── */
async function deleteSessionEx(seid) {
  try {
    const ownerSession = _sessionForExercise(seid);
    await apiFetch(`/api/session-exercises/${seid}`, { method: "DELETE" });
    await _syncAndRefresh(ownerSession?.day_number ?? null);
  } catch (err) { alert("Error: " + err.message); }
}

/* ── Session exercise modal ───────────────────────────────────────────────── */
let sexSearchTimer;

function openSessionExModal(sessionId, exData) {
  pState.sexSessionId = sessionId;
  pState.sexEditId    = exData ? exData.id : null;
  pState.sexSelectedEx = exData ? { id: exData.exercise_id, name: exData.exercise_name } : null;

  $("sessionExTitle").textContent = exData ? "Edit Exercise" : "Add Exercise";
  $("sex-search").value = "";
  $("sexSearchResults").innerHTML = "";

  if (pState.sexSelectedEx && pState.sexSelectedEx.name) {
    $("sexSelectedDisplay").classList.remove("hidden");
    $("sexSelectedName").textContent = pState.sexSelectedEx.name;
  } else {
    $("sexSelectedDisplay").classList.add("hidden");
    $("sexSelectedName").textContent = "—";
  }

  // Fill defaults from goal or from existing exercise data
  const goal = pState.currentProgram ? pState.currentProgram.goal : "strength";
  const defaults = GOAL_DEFAULTS[goal] || GOAL_DEFAULTS.mixed;

  $("sex-sets").value          = exData ? (exData.sets || "")          : defaults.sets;
  $("sex-reps").value          = exData ? (exData.reps || "")          : defaults.reps;
  $("sex-intensity-type").value= exData ? (exData.intensity_type || "") : defaults.intensity_type;
  $("sex-intensity-val").value = exData ? (exData.intensity_value || "") : defaults.intensity_value;
  $("sex-rest").value          = exData ? (exData.rest_seconds || "")  : defaults.rest_seconds;
  $("sex-tempo").value         = exData ? (exData.tempo || "")         : "";
  $("sex-notes").value         = exData ? (exData.notes || "")         : "";

  // Reset working weight display, then try to compute it
  $("workingWeightDisplay").classList.add("hidden");
  updateWorkingWeight();

  $("sessionExModal").classList.remove("hidden");
  $("sex-search").focus();
}

$("sex-search").addEventListener("input", e => {
  clearTimeout(sexSearchTimer);
  const val = e.target.value.trim();
  if (!val) { $("sexSearchResults").innerHTML = ""; return; }
  sexSearchTimer = setTimeout(async () => {
    const results = await apiFetch(`/api/exercises?search=${encodeURIComponent(val)}`);
    renderSexResults(results.slice(0, 10));
  }, 250);
});

function renderSexResults(exercises) {
  const container = $("sexSearchResults");
  container.innerHTML = "";
  if (exercises.length === 0) {
    container.innerHTML = `<div style="padding:10px 12px;font-size:.8rem;color:#9CA3AF">No exercises found</div>`;
    return;
  }
  exercises.forEach(ex => {
    const item = document.createElement("div");
    item.className = "ex-search-result-item" + (pState.sexSelectedEx?.id === ex.id ? " selected" : "");
    item.innerHTML = `
      <span>${esc(ex.name)}</span>
      <span class="ex-search-result-pattern">${esc(ex.movement_pattern)}</span>
    `;
    item.addEventListener("click", () => {
      pState.sexSelectedEx = { id: ex.id, name: ex.name };
      $("sexSelectedDisplay").classList.remove("hidden");
      $("sexSelectedName").textContent = ex.name;
      $("sexSearchResults").innerHTML = "";
      $("sex-search").value = "";
      updateWorkingWeight();
    });
    container.appendChild(item);
  });
}

$("sessionExSave").addEventListener("click", async () => {
  if (!pState.sexSelectedEx && !$("sex-reps").value && !$("sex-sets").value) {
    alert("Please search and select an exercise, or fill in at least sets/reps.");
    return;
  }
  const payload = {
    exercise_id:     pState.sexSelectedEx?.id   || null,
    exercise_name:   pState.sexSelectedEx?.name || null,
    sets:            parseInt($("sex-sets").value)   || null,
    reps:            $("sex-reps").value.trim()       || null,
    intensity_type:  $("sex-intensity-type").value    || null,
    intensity_value: $("sex-intensity-val").value.trim() || null,
    rest_seconds:    parseInt($("sex-rest").value)    || null,
    tempo:           $("sex-tempo").value.trim()       || null,
    notes:           $("sex-notes").value.trim()       || null,
  };
  try {
    if (pState.sexEditId) {
      await apiFetch(`/api/session-exercises/${pState.sexEditId}`, { method: "PUT", body: JSON.stringify(payload) });
    } else {
      await apiFetch(`/api/sessions/${pState.sexSessionId}/exercises`, { method: "POST", body: JSON.stringify(payload) });
    }
    const day = _dayForSession(pState.sexSessionId);
    closeModal("sessionExModal");
    await _syncAndRefresh(day);
  } catch (err) { alert("Error: " + err.message); }
});

$("sessionExClose").addEventListener("click",  () => closeModal("sessionExModal"));
$("sessionExCancel").addEventListener("click", () => closeModal("sessionExModal"));
$("sessionExModal").addEventListener("click", e => { if (e.target === $("sessionExModal")) closeModal("sessionExModal"); });

// Recalculate working weight whenever intensity type or value changes
$("sex-intensity-type").addEventListener("change", updateWorkingWeight);
$("sex-intensity-val").addEventListener("input",  updateWorkingWeight);

/* ── New/Edit Program Modal ───────────────────────────────────────────────── */
let _editingProgramId = null;

async function openNewProgramModal(programData = null) {
  _editingProgramId = programData ? programData.id : null;
  if (programData) {
    $("programModalTitle").textContent = "Edit Program";
  } else if (pState.contextAthleteName) {
    $("programModalTitle").textContent = `New Program — ${pState.contextAthleteName}`;
  } else {
    $("programModalTitle").textContent = "New Training Program";
  }
  $("programModalSave").innerHTML = programData
    ? '<i class="fa-solid fa-check"></i> Save Changes'
    : '<i class="fa-solid fa-check"></i> Create Program';

  $("pm-name").value = programData?.name || "";
  $("pm-start-date").value = programData?.start_date || "";
  $("pm-notes").value = programData?.notes || "";

  // Weeks slider
  const weeks = programData?.duration_weeks || 8;
  $("pm-weeks").value = weeks;
  $("pm-weeks-val").textContent = weeks;
  _updateProgramEndDate();

  // Days selector
  const days = programData?.days_per_week || 3;
  $("pm-days-selector").querySelectorAll(".day-btn").forEach(b => {
    b.classList.toggle("active", parseInt(b.dataset.val) === days);
  });

  // Chip selectors
  setChipSelectorValue("pm-goal-chips",   programData?.goal               || "strength");
  setChipSelectorValue("pm-period-chips", programData?.periodization_type || "block");
  setChipSelectorValue("pm-level-chips",  programData?.athlete_level      || "intermediate");
  setChipSelectorValue("pm-sport-chips",  programData?.sport              || "general");

  // Team select
  const teamSection = $("pm-team-section");
  const teamSelect = $("pm-team-select");
  if (pState.contextAthleteId) {
    teamSection.classList.add("hidden");
  } else {
    teamSection.classList.remove("hidden");
    const teams = await apiFetch("/api/teams").catch(() => []);
    teamSelect.innerHTML = '<option value="">No team</option>';
    teams.forEach(t => {
      const opt = document.createElement("option");
      opt.value = t.id;
      opt.textContent = t.name + (t.sport ? ` (${t.sport})` : "");
      if (programData?.team_id === t.id || pState.contextTeamId === t.id) opt.selected = true;
      teamSelect.appendChild(opt);
    });
  }

  $("programModal").classList.remove("hidden");
  $("pm-name").focus();
}

function setChipSelectorValue(containerId, value) {
  $(containerId).querySelectorAll(".chip").forEach(c => {
    c.classList.toggle("active", c.dataset.val === value);
  });
}

function getChipSelectorValue(containerId) {
  const active = $(containerId).querySelector(".chip.active");
  return active ? active.dataset.val : null;
}

// Weeks slider live update + end date recalc
$("pm-weeks").addEventListener("input", e => {
  $("pm-weeks-val").textContent = e.target.value;
  _updateProgramEndDate();
});

$("pm-start-date").addEventListener("change", _updateProgramEndDate);

function _updateProgramEndDate() {
  const startVal = $("pm-start-date").value;
  const weeks = parseInt($("pm-weeks").value) || 0;
  const endField = $("pm-end-date");
  if (startVal && weeks > 0) {
    const end = new Date(startVal);
    end.setDate(end.getDate() + weeks * 7 - 1);
    endField.value = end.toISOString().slice(0, 10);
  } else {
    endField.value = "";
  }
}

// Days selector buttons
$("pm-days-selector").addEventListener("click", e => {
  const btn = e.target.closest(".day-btn");
  if (!btn) return;
  $("pm-days-selector").querySelectorAll(".day-btn").forEach(b => b.classList.remove("active"));
  btn.classList.add("active");
});

// Chip single-select in program modal
["pm-goal-chips", "pm-period-chips", "pm-level-chips", "pm-sport-chips"].forEach(id => {
  $(id).addEventListener("click", e => {
    const chip = e.target.closest(".chip");
    if (!chip) return;
    $(id).querySelectorAll(".chip").forEach(c => c.classList.remove("active"));
    chip.classList.add("active");
  });
});

$("programModalSave").addEventListener("click", async () => {
  const name = $("pm-name").value.trim();
  if (!name) { alert("Please enter a program name."); $("pm-name").focus(); return; }

  const activeDay = $("pm-days-selector").querySelector(".day-btn.active");
  const payload = {
    name,
    start_date:         $("pm-start-date").value || null,
    duration_weeks:     parseInt($("pm-weeks").value),
    days_per_week:      activeDay ? parseInt(activeDay.dataset.val) : 3,
    goal:               getChipSelectorValue("pm-goal-chips")   || "strength",
    periodization_type: getChipSelectorValue("pm-period-chips") || "block",
    athlete_level:      getChipSelectorValue("pm-level-chips")  || null,
    sport:              getChipSelectorValue("pm-sport-chips")  || null,
    notes:              $("pm-notes").value.trim() || null,
    athlete_id:         pState.contextAthleteId || null,
    team_id:            parseInt($("pm-team-select").value) || null,
  };

  try {
    if (_editingProgramId) {
      await apiFetch(`/api/programs/${_editingProgramId}`, { method: "PUT", body: JSON.stringify(payload) });
      closeModal("programModal");
      await loadPrograms();
    } else {
      const created = await apiFetch("/api/programs", { method: "POST", body: JSON.stringify(payload) });
      const fromAthlete = pState.contextAthleteId;
      const fromTeam = pState.contextTeamId;
      pState.contextAthleteId   = null;
      pState.contextAthleteName = null;
      pState.contextTeamId      = null;
      pState.contextTeamName    = null;
      closeModal("programModal");
      if (fromAthlete) {
        pState.fromAthleteId = fromAthlete;
      }
      if (fromTeam) {
        pState.fromTeamId = fromTeam;
      }
      await openProgramEditor(created.id);
      return;
    }
  } catch (err) { alert("Error: " + err.message); }
});

$("programModalClose").addEventListener("click",  () => closeModal("programModal"));
$("programModalCancel").addEventListener("click", () => closeModal("programModal"));
$("programModal").addEventListener("click", e => { if (e.target === $("programModal")) closeModal("programModal"); });

/* ── Delete program ───────────────────────────────────────────────────────── */
function confirmDeleteProgram(p) {
  $("confirmMsg").textContent = `Delete program "${p.name}"? This will remove all weeks, sessions, and exercises.`;
  $("confirmModal").classList.remove("hidden");
  $("confirmYes").onclick = async () => {
    try {
      await apiFetch(`/api/programs/${p.id}`, { method: "DELETE" });
      closeModal("confirmModal");
      await loadPrograms();
    } catch (err) { alert("Error: " + err.message); }
  };
}

/* ── Keyboard close for new modals ────────────────────────────────────────── */
document.addEventListener("keydown", e => {
  if (e.key === "Escape") {
    closeModal("programModal");
    closeModal("sessionExModal");
    closeModal("oneRMModal");
  }
}, true);

/* ── Init programs ────────────────────────────────────────────────────────── */
function initPrograms() {
  // Nothing async needed at startup — programs and 1RM load on tab switch

  // Athlete simplified view: back button and week prev/next
  $("apvBackBtn").addEventListener("click", () => {
    $("athleteProgramView").classList.add("hidden");
    $("programsList").classList.remove("hidden");
  });

  $("apvPrevWeek").addEventListener("click", () => {
    if (pState.apvWeekNum > 1) {
      pState.apvWeekNum--;
      pState.apvDayNum = 1;
      renderApvWeekTabs();
      renderApvDayTabs();
      renderApvExercises();
    }
  });

  $("apvNextWeek").addEventListener("click", () => {
    const maxWeek = (pState.currentProgram?.weeks || []).length;
    if (pState.apvWeekNum < maxWeek) {
      pState.apvWeekNum++;
      pState.apvDayNum = 1;
      renderApvWeekTabs();
      renderApvDayTabs();
      renderApvExercises();
    }
  });
}

/* ═══════════════════════════════════════════════════════════════════════════
   1RM RECORDS FEATURE
   ═══════════════════════════════════════════════════════════════════════════ */

/* ── 1RM state ────────────────────────────────────────────────────────────── */
const ormState = {
  records:          [],
  editingId:        null,
  selectedEx:       null,    // { id, name } from exercise search
  ormExSearchTimer: null,
  athleteId:        null,    // athlete context when adding 1RM from athlete detail
};

/* ── Load & render 1RM table ──────────────────────────────────────────────── */
async function loadOneRM(searchTerm) {
  const qs = searchTerm ? `?search=${encodeURIComponent(searchTerm)}` : "";
  ormState.records = await apiFetch(`/api/one-rm${qs}`);
  renderORMTable();
  // Derived 1RMs only shown when not filtering (search is empty)
  if (!searchTerm) {
    const derived = await apiFetch("/api/one-rm/derived").catch(() => []);
    renderDerivedRMTable(derived);
  } else {
    $("derivedRMSection").classList.add("hidden");
  }
}

function renderORMTable() {
  const tbody  = $("ormTableBody");
  const empty  = $("ormEmpty");
  tbody.innerHTML = "";

  if (ormState.records.length === 0) {
    empty.classList.remove("hidden");
    return;
  }
  empty.classList.add("hidden");

  ormState.records.forEach(r => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td class="one-rm-exercise-name">${esc(r.exercise_name)}</td>
      <td><span class="one-rm-weight">${esc(r.weight_kg)} kg</span></td>
      <td class="one-rm-date">${r.test_date ? esc(r.test_date) : "—"}</td>
      <td class="one-rm-notes-cell" title="${esc(r.notes || "")}">${r.notes ? esc(r.notes) : "—"}</td>
      <td>
        <div class="one-rm-actions">
          <button class="btn-icon" title="Edit" onclick="openOneRMModal(${r.id})"><i class="fa-solid fa-pen"></i></button>
          <button class="btn-icon danger" title="Delete" onclick="deleteORMRecord(${r.id}, '${esc(r.exercise_name).replace(/'/g,"\\'")}')"><i class="fa-solid fa-trash"></i></button>
        </div>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

/* ── Derived (calculated) 1RM table ──────────────────────────────────────── */
function renderDerivedRMTable(derived) {
  const section = $("derivedRMSection");
  const tbody   = $("derivedRMTableBody");
  tbody.innerHTML = "";

  if (!derived || derived.length === 0) {
    section.classList.add("hidden");
    return;
  }

  section.classList.remove("hidden");
  derived.forEach(d => {
    const tr = document.createElement("tr");
    const pctLabel = (d.factor * 100).toFixed(d.factor % 0.01 === 0 ? 0 : 1) + "%";
    tr.innerHTML = `
      <td class="one-rm-exercise-name">${esc(d.exercise_name)}</td>
      <td><span class="one-rm-weight derived-weight">${d.weight_kg.toFixed(1)} kg${d.per_hand ? " <span class=\"per-hand-badge\">each hand</span>" : ""}</span></td>
      <td class="derived-formula">${esc(pctLabel)} of ${esc(d.source_name)} (${d.source_weight} kg)</td>
    `;
    tbody.appendChild(tr);
  });
}

/* ── 1RM search box ───────────────────────────────────────────────────────── */
let ormSearchTimer;
$("ormSearchInput").addEventListener("input", e => {
  clearTimeout(ormSearchTimer);
  ormSearchTimer = setTimeout(() => loadOneRM(e.target.value.trim()), 300);
});

/* ── Open 1RM modal ───────────────────────────────────────────────────────── */
function openOneRMModal(recordIdOrObj) {
  // Accept either a numeric id (from the main 1RM table) or a full record object (from athlete detail)
  let existing = null;
  if (recordIdOrObj && typeof recordIdOrObj === "object") {
    existing = recordIdOrObj;
  } else if (recordIdOrObj) {
    existing = ormState.records.find(r => r.id === recordIdOrObj) || null;
  }
  ormState.editingId = existing ? existing.id : null;
  ormState.selectedEx = existing
    ? { id: existing.exercise_id, name: existing.exercise_name }
    : null;

  $("ormModalTitle").textContent = existing ? "Edit 1RM Record" : "Add 1RM Record";
  $("orm-ex-search").value = "";
  $("ormExSearchResults").innerHTML = "";
  $("ormCalcResult").classList.add("hidden");
  $("orm-calc-weight").value = "";
  $("orm-calc-reps").value   = "";

  if (ormState.selectedEx) {
    $("ormSelectedDisplay").classList.remove("hidden");
    $("ormSelectedName").textContent = ormState.selectedEx.name;
  } else {
    $("ormSelectedDisplay").classList.add("hidden");
    $("ormSelectedName").textContent = "—";
  }

  $("orm-weight").value = existing ? existing.weight_kg : "";
  $("orm-date").value   = existing ? (existing.test_date || "") : "";
  $("orm-notes").value  = existing ? (existing.notes || "") : "";

  $("oneRMModal").classList.remove("hidden");
  $("orm-ex-search").focus();
}

/* ── Exercise search inside 1RM modal ────────────────────────────────────── */
let ormExSearchTimer;
$("orm-ex-search").addEventListener("input", e => {
  clearTimeout(ormExSearchTimer);
  const val = e.target.value.trim();
  if (!val) { $("ormExSearchResults").innerHTML = ""; return; }
  ormExSearchTimer = setTimeout(async () => {
    const results = await apiFetch(`/api/exercises?search=${encodeURIComponent(val)}`);
    renderORMExResults(results.slice(0, 10));
  }, 250);
});

function renderORMExResults(exercises) {
  const container = $("ormExSearchResults");
  container.innerHTML = "";
  if (exercises.length === 0) {
    container.innerHTML = `<div style="padding:10px 12px;font-size:.8rem;color:#9CA3AF">No exercises found</div>`;
    return;
  }
  exercises.forEach(ex => {
    const item = document.createElement("div");
    item.className = "ex-search-result-item" + (ormState.selectedEx?.id === ex.id ? " selected" : "");
    item.innerHTML = `
      <span>${esc(ex.name)}</span>
      <span class="ex-search-result-pattern">${esc(ex.movement_pattern)}</span>
    `;
    item.addEventListener("click", () => {
      ormState.selectedEx = { id: ex.id, name: ex.name };
      $("ormSelectedDisplay").classList.remove("hidden");
      $("ormSelectedName").textContent = ex.name;
      $("ormExSearchResults").innerHTML = "";
      $("orm-ex-search").value = "";
    });
    container.appendChild(item);
  });
}

/* ── 1RM Calculator (Epley formula) ──────────────────────────────────────── */
// Epley: 1RM = weight × (1 + reps / 30)
// Brzycki: 1RM = weight × (36 / (37 − reps))
// We use Epley as primary, show both if desired
function calcOneRM(weightKg, reps) {
  if (reps === 1) return weightKg;
  return weightKg * (1 + reps / 30);
}

$("ormCalcBtn").addEventListener("click", () => {
  const w = parseFloat($("orm-calc-weight").value);
  const r = parseInt($("orm-calc-reps").value);
  if (!w || !r || r < 1 || r > 30) {
    alert("Enter a valid weight and rep count (1–30).");
    return;
  }
  const estimated = calcOneRM(w, r);
  const rounded = Math.round(estimated * 4) / 4; // round to nearest 0.25 kg
  $("ormCalcValue").textContent = `${rounded.toFixed(2)} kg`;
  $("ormCalcResult").classList.remove("hidden");
  $("ormCalcUseBtn").dataset.value = rounded.toFixed(2);
});

$("ormCalcUseBtn").addEventListener("click", () => {
  $("orm-weight").value = $("ormCalcUseBtn").dataset.value;
});

/* ── Save 1RM record ──────────────────────────────────────────────────────── */
$("ormModalSave").addEventListener("click", async () => {
  const weight = $("orm-weight").value.trim();
  if (!weight || isNaN(parseFloat(weight))) {
    alert("Please enter a valid weight.");
    $("orm-weight").focus();
    return;
  }
  const exerciseName = ormState.selectedEx?.name || prompt("Exercise name:");
  if (!exerciseName) return;

  const payload = {
    exercise_id:   ormState.selectedEx?.id || null,
    exercise_name: exerciseName,
    weight_kg:     weight,
    test_date:     $("orm-date").value || null,
    notes:         $("orm-notes").value.trim() || null,
    athlete_id:    ormState.athleteId || null,
  };

  try {
    if (ormState.editingId) {
      await apiFetch(`/api/one-rm/${ormState.editingId}`, { method: "PUT", body: JSON.stringify(payload) });
    } else {
      await apiFetch("/api/one-rm", { method: "POST", body: JSON.stringify(payload) });
    }
    closeModal("oneRMModal");
    const athleteCtx = ormState.athleteId;
    ormState.athleteId = null;
    if (athleteCtx) {
      await loadAthleteORM(athleteCtx);
    } else {
      await loadOneRM($("ormSearchInput").value.trim() || undefined);
    }
  } catch (err) { alert("Error: " + err.message); }
});

$("ormModalClose").addEventListener("click",  () => closeModal("oneRMModal"));
$("ormModalCancel").addEventListener("click", () => closeModal("oneRMModal"));
$("oneRMModal").addEventListener("click", e => { if (e.target === $("oneRMModal")) closeModal("oneRMModal"); });

/* ── Delete 1RM record ────────────────────────────────────────────────────── */
async function deleteORMRecord(id, name) {
  $("confirmMsg").textContent = `Delete 1RM record for "${name}"?`;
  $("confirmModal").classList.remove("hidden");
  $("confirmYes").onclick = async () => {
    try {
      await apiFetch(`/api/one-rm/${id}`, { method: "DELETE" });
      closeModal("confirmModal");
      await loadOneRM($("ormSearchInput").value.trim() || undefined);
    } catch (err) { alert("Error: " + err.message); }
  };
}

/* ── Working weight auto-calculation in session exercise modal ────────────── */
async function updateWorkingWeight() {
  const intensityType = $("sex-intensity-type").value;
  const intensityVal  = parseFloat($("sex-intensity-val").value);
  const exerciseId    = pState.sexSelectedEx?.id;

  const display = $("workingWeightDisplay");

  if (intensityType !== "pct_1rm" || !intensityVal || intensityVal <= 0) {
    display.classList.add("hidden");
    return;
  }

  if (!exerciseId) {
    display.classList.add("hidden");
    return;
  }

  try {
    const athleteId = (typeof aState !== "undefined" && aState.currentAthlete?.id) || pState.contextAthleteId;
    const url = `/api/one-rm/exercise/${exerciseId}${athleteId ? `?athlete_id=${athleteId}` : ""}`;
    const record = await apiFetch(url);
    const oneRM   = parseFloat(record.weight_kg);
    if (isNaN(oneRM)) { display.classList.add("hidden"); return; }

    const working = oneRM * (intensityVal / 100);
    // Round to nearest 2.5 kg (standard plate increment)
    const rounded = Math.round(working / 2.5) * 2.5;

    $("workingWeightValue").textContent = `${rounded.toFixed(1)} kg`;
    $("workingWeightSub").textContent =
      `${intensityVal}% of ${oneRM} kg 1RM · exact: ${working.toFixed(1)} kg`;
    display.classList.remove("hidden");
  } catch {
    // No 1RM record found for this exercise — hide display
    display.classList.add("hidden");
  }
}

/* ═══════════════════════════════════════════════════════════════════════════
   ATHLETES FEATURE
   ═══════════════════════════════════════════════════════════════════════════ */

/* ── Athlete state ────────────────────────────────────────────────────────── */
const aState = {
  athletes:       [],
  currentAthlete: null,
  editingId:      null,
};

/* ── Sport icon/color maps ────────────────────────────────────────────────── */
const SPORT_ICONS = {
  gymnastics:  "fa-solid fa-ring",
  football:    "fa-solid fa-football",
  soccer:      "fa-solid fa-futbol",
  basketball:  "fa-solid fa-basketball",
  volleyball:  "fa-solid fa-volleyball",
  general:     "fa-solid fa-person-running",
};

const SPORT_COLORS = {
  gymnastics:  "#059669",
  football:    "#D97706",
  soccer:      "#16A34A",
  basketball:  "#EA580C",
  volleyball:  "#7C3AED",
  general:     "#4A7CF6",
};

const LEVEL_COLORS = {
  beginner:     { bg: "#F0FDF4", text: "#166534" },
  intermediate: { bg: "#EFF6FF", text: "#1D4ED8" },
  advanced:     { bg: "#FEF3C7", text: "#B45309" },
  elite:        { bg: "#FDF4FF", text: "#7E22CE" },
};

function sportColor(s) { return SPORT_COLORS[s] || "#6B7280"; }
function sportIcon(s)  { return SPORT_ICONS[s]  || "fa-solid fa-person-running"; }
function levelStyle(l) { return LEVEL_COLORS[l] || { bg: "#F1F5F9", text: "#475569" }; }

/* ── Load & render athletes ───────────────────────────────────────────────── */
async function loadAthletes() {
  aState.athletes = await apiFetch("/api/athletes");
  state.athletes  = aState.athletes;
  renderAthletes();
}

function renderAthletes() {
  const grid  = $("athletesGrid");
  const empty = $("athletesEmpty");
  grid.innerHTML = "";

  if (aState.athletes.length === 0) {
    empty.classList.remove("hidden");
    return;
  }
  empty.classList.add("hidden");

  aState.athletes.forEach(a => {
    const card = document.createElement("div");
    card.className = "athlete-card";
    const age    = a.birth_year ? new Date().getFullYear() - a.birth_year : null;
    const ageStr = age ? "Age: " + age : "";
    const ls     = levelStyle(a.level);
    const sc     = sportColor(a.sport);
    const si     = sportIcon(a.sport);

    const levelBadge = a.level
      ? `<div class="athlete-card-level" style="background:${ls.bg};color:${ls.text}">${esc(a.level)}</div>`
      : "";
    const sportSpan = a.sport
      ? `<span style="color:${sc};font-weight:600;text-transform:capitalize">${esc(a.sport)}</span>`
      : "";
    const posSpan = a.position
      ? `<span class="athlete-card-position">&middot; ${esc(a.position)}</span>`
      : "";
    const ageStat = ageStr
      ? `<div class="athlete-stat"><i class="fa-solid fa-cake-candles"></i> ${ageStr}</div>`
      : "";

    card.innerHTML = `
      <div class="athlete-card-sport-bar" style="background:${sc}"></div>
      <div class="athlete-card-body">
        <div class="athlete-card-header">
          <div class="athlete-card-avatar" style="background:${sc}22;color:${sc}">
            <i class="${si}"></i>
          </div>
          <div class="athlete-card-info">
            <div class="athlete-card-name">${esc(a.name)}</div>
            <div class="athlete-card-sub">${sportSpan}${posSpan}</div>
          </div>
          ${levelBadge}
        </div>
        <div class="athlete-card-stats">
          ${ageStat}
          <div class="athlete-stat"><i class="fa-solid fa-calendar-days"></i> ${a.program_count || 0} programs</div>
          <div class="athlete-stat"><i class="fa-solid fa-weight-hanging"></i> ${a.one_rm_count || 0} max records</div>
          ${a.username
            ? `<div class="athlete-stat" title="Login username"><i class="fa-solid fa-user" style="color:#3B82F6"></i> ${esc(a.username)}</div>`
            : `<div class="athlete-stat" style="color:#F97316" title="No login account yet"><i class="fa-solid fa-user-slash"></i> No account</div>`}
        </div>
        <div class="athlete-card-footer">
          <button class="btn-primary btn-sm open-athlete-btn" data-id="${a.id}">
            <i class="fa-solid fa-arrow-right"></i> Open
          </button>
          <button class="btn-ghost btn-sm edit-athlete-btn" data-id="${a.id}" title="Edit">
            <i class="fa-solid fa-pen"></i>
          </button>
          <button class="btn-danger btn-sm delete-athlete-btn" data-id="${a.id}" title="Delete">
            <i class="fa-solid fa-trash"></i>
          </button>
        </div>
      </div>
    `;
    grid.appendChild(card);
  });

  grid.querySelectorAll(".open-athlete-btn").forEach(btn => {
    btn.addEventListener("click", () => openAthleteDetail(parseInt(btn.dataset.id)));
  });
  grid.querySelectorAll(".edit-athlete-btn").forEach(btn => {
    btn.addEventListener("click", () => openAthleteModal(parseInt(btn.dataset.id)));
  });
  grid.querySelectorAll(".delete-athlete-btn").forEach(btn => {
    btn.addEventListener("click", () => deleteAthlete(parseInt(btn.dataset.id)));
  });
}

/* ── Athlete detail view ──────────────────────────────────────────────────── */
async function openAthleteDetail(aid) {
  const a = aState.athletes.find(x => x.id === aid) || await apiFetch("/api/athletes/" + aid);
  aState.currentAthlete = a;
  state.currentAthleteId = aid;

  const age = a.birth_year ? (new Date().getFullYear() - a.birth_year) + " yrs" : null;
  const sc  = sportColor(a.sport);
  const ls  = levelStyle(a.level);

  $("athleteDetailName").textContent = a.name;

  const sep = '<span style="color:#E5E7EB;margin:0 6px">&middot;</span>';
  const metaParts = [];
  if (a.sport)    metaParts.push(`<span style="color:${sc};font-weight:600;text-transform:capitalize"><i class="${sportIcon(a.sport)}"></i> ${esc(a.sport)}</span>`);
  if (a.position) metaParts.push(`<span>${esc(a.position)}</span>`);
  if (a.level)    metaParts.push(`<span style="background:${ls.bg};color:${ls.text};padding:2px 8px;border-radius:99px;font-size:.75rem;font-weight:600">${esc(a.level)}</span>`);
  if (age)        metaParts.push(`<span style="color:#9CA3AF">${age}</span>`);
  if (a.gender)   metaParts.push(`<span style="color:#9CA3AF;text-transform:capitalize">${esc(a.gender)}</span>`);
  if (a.username) metaParts.push(`<span style="color:#3B82F6"><i class="fa-solid fa-user"></i> ${esc(a.username)}</span>`);
  $("athleteDetailMeta").innerHTML = metaParts.join(sep);

  switchView("athlete-detail");
  await loadAthletePrograms(aid);
  await loadAthleteORM(aid);
}

async function loadAthletePrograms(aid) {
  const programs = await apiFetch("/api/athletes/" + aid + "/programs");
  const grid  = $("athleteProgramsGrid");
  const empty = $("athleteProgramsEmpty");
  grid.innerHTML = "";

  if (programs.length === 0) {
    empty.classList.remove("hidden");
    return;
  }
  empty.classList.add("hidden");

  programs.forEach(p => {
    const card = document.createElement("div");
    card.className = "program-card";
    const goalCls   = "goal-" + p.goal;
    const phasesBar = (p.phases || []).map(ph =>
      `<div class="phase-bar-segment" style="background:${PHASE_COLORS[ph] || '#CBD5E1'}" title="${ph}"></div>`
    ).join("");
    const levelLabel = p.athlete_level ? `<span class="program-badge">${esc(p.athlete_level)}</span>` : "";
    const sportLabel = p.sport         ? `<span class="program-badge">${esc(p.sport)}</span>` : "";
    const startLabel = p.start_date    ? `<span>From ${esc(p.start_date)}</span>` : "<span>No start date</span>";

    card.innerHTML = `
      <div class="program-card-name">${esc(p.name)}</div>
      <div class="program-card-meta">
        <span class="program-badge ${goalCls}">${esc(p.goal)}</span>
        <span class="program-badge">${p.duration_weeks}w &middot; ${p.days_per_week}d/wk</span>
        ${levelLabel}${sportLabel}
      </div>
      <div class="phase-bar">${phasesBar}</div>
      <div class="program-card-footer">
        ${startLabel}
        <div class="program-card-actions">
          <button class="btn-ghost btn-sm open-prog-from-athlete" data-id="${p.id}" title="Open">
            <i class="fa-solid fa-arrow-right"></i> Open
          </button>
          <button class="btn-danger btn-sm delete-prog-athlete" data-id="${p.id}" title="Delete">
            <i class="fa-solid fa-trash"></i>
          </button>
        </div>
      </div>
    `;
    grid.appendChild(card);
  });

  grid.querySelectorAll(".open-prog-from-athlete").forEach(btn => {
    btn.addEventListener("click", () => {
      pState.fromAthleteId = aState.currentAthlete?.id;
      openProgramFromAthleteDetail(parseInt(btn.dataset.id));
    });
  });
  grid.querySelectorAll(".delete-prog-athlete").forEach(btn => {
    btn.addEventListener("click", () => deleteAthleteProgram(parseInt(btn.dataset.id)));
  });
}

async function openProgramFromAthleteDetail(pid) {
  if (!pState.programs.length) {
    pState.programs = await apiFetch("/api/programs");
  }
  switchView("programs");
  await openProgramEditor(pid);
}

async function deleteAthleteProgram(pid) {
  $("confirmMsg").textContent = "Delete this program? This cannot be undone.";
  $("confirmModal").classList.remove("hidden");
  $("confirmYes").onclick = async () => {
    try {
      await apiFetch("/api/programs/" + pid, { method: "DELETE" });
      closeModal("confirmModal");
      await loadAthletePrograms(aState.currentAthlete.id);
    } catch (err) { alert("Error: " + err.message); }
  };
}

async function loadAthleteORM(aid) {
  const records = await apiFetch("/api/athletes/" + aid + "/one-rm");
  const tbody = $("athleteORMTableBody");
  const empty = $("athleteORMEmpty");
  tbody.innerHTML = "";

  if (records.length === 0) {
    empty.classList.remove("hidden");
    return;
  }
  empty.classList.add("hidden");

  records.forEach(r => {
    const tr = document.createElement("tr");
    const notesCell = r.notes    ? esc(r.notes)     : '<span style="color:#9CA3AF">&mdash;</span>';
    const dateCell  = r.test_date ? esc(r.test_date) : '<span style="color:#9CA3AF">&mdash;</span>';
    tr.innerHTML = `
      <td><strong>${esc(r.exercise_name)}</strong></td>
      <td><span style="font-weight:700;color:#1E293B">${esc(r.weight_kg)} kg</span></td>
      <td>${dateCell}</td>
      <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${notesCell}</td>
      <td>
        <div style="display:flex;gap:6px">
          <button class="btn-ghost btn-sm orm-edit-btn"><i class="fa-solid fa-pen"></i></button>
          <button class="btn-danger btn-sm orm-del-btn"><i class="fa-solid fa-trash"></i></button>
        </div>
      </td>
    `;
    tr.querySelector(".orm-edit-btn").addEventListener("click", () => openORMModalForAthlete(aid, r));
    tr.querySelector(".orm-del-btn").addEventListener("click",  () => deleteAthleteORM(r.id, r.exercise_name));
    tbody.appendChild(tr);
  });
}

function openORMModalForAthlete(aid, record) {
  ormState.athleteId = aid;
  openOneRMModal(record);
}

async function deleteAthleteORM(rid, name) {
  $("confirmMsg").textContent = 'Delete 1RM record for "' + name + '"?';
  $("confirmModal").classList.remove("hidden");
  $("confirmYes").onclick = async () => {
    try {
      await apiFetch("/api/one-rm/" + rid, { method: "DELETE" });
      closeModal("confirmModal");
      await loadAthleteORM(aState.currentAthlete.id);
    } catch (err) { alert("Error: " + err.message); }
  };
}

/* ── Username slug generator (mirrors Python backend) ─────────────────────── */
function slugAthleteUsername(name) {
  const tr = { 'ı':'i','İ':'i','ğ':'g','Ğ':'g','ü':'u','Ü':'u','ş':'s','Ş':'s','ö':'o','Ö':'o','ç':'c','Ç':'c' };
  let s = name.toLowerCase().replace(/[ıİğĞüÜşŞöÖçÇ]/g, ch => tr[ch] || ch);
  s = s.replace(/[^a-z0-9]+/g, '.').replace(/^\.+|\.+$/g, '');
  return s;
}

/* ── New/Edit Athlete Modal ───────────────────────────────────────────────── */
async function openAthleteModal(athleteId) {
  if (athleteId === undefined) athleteId = null;
  aState.editingId = athleteId;
  const isEdit = !!athleteId;
  $("athleteModalTitle").textContent = isEdit ? "Edit Athlete" : "New Athlete";

  // Reset form
  $("am-name").value            = "";
  $("am-birth-year").value      = "";
  $("am-position").value        = "";
  $("am-notes").value           = "";
  $("am-password").value        = "";
  $("am-password-confirm").value= "";
  resetChips("am-sport-chips");
  resetChips("am-gender-chips");
  resetChips("am-level-chips", "intermediate");

  // Password section: on create = required; on edit = optional (leave blank = keep)
  $("am-password-label").innerHTML = isEdit
    ? 'New Password <span class="hint">(optional)</span>'
    : 'Password <span class="req">*</span>';
  $("am-password-hint").classList.toggle("hidden", !isEdit);
  $("am-username-preview").classList.add("hidden");
  $("am-existing-username").classList.add("hidden");

  if (isEdit) {
    const a = aState.athletes.find(x => x.id === athleteId) || await apiFetch("/api/athletes/" + athleteId);
    $("am-name").value       = a.name       || "";
    $("am-birth-year").value = a.birth_year || "";
    $("am-position").value   = a.position   || "";
    $("am-notes").value      = a.notes      || "";
    setChip("am-sport-chips",  a.sport  || "");
    setChip("am-gender-chips", a.gender || "");
    setChip("am-level-chips",  a.level  || "intermediate");

    if (a.username) {
      $("am-existing-username-value").textContent = a.username;
      $("am-existing-username").classList.remove("hidden");
    } else {
      // No account yet — show slug preview so coach knows what will be created
      updateUsernamePreview(a.name);
    }
  }

  $("athleteModal").classList.remove("hidden");
  $("am-name").focus();
}

function updateUsernamePreview(name) {
  if (!aState.editingId && name.trim().length > 1) {
    $("am-username-value").textContent = slugAthleteUsername(name.trim());
    $("am-username-preview").classList.remove("hidden");
  } else {
    $("am-username-preview").classList.add("hidden");
  }
}

$("am-name").addEventListener("input", () => {
  updateUsernamePreview($("am-name").value);
});

function resetChips(containerId, defaultVal) {
  if (defaultVal === undefined) defaultVal = "";
  const container = $(containerId);
  container.querySelectorAll(".chip").forEach(c => {
    c.classList.toggle("active", c.dataset.val === defaultVal);
  });
}

function setChip(containerId, val) {
  const container = $(containerId);
  container.querySelectorAll(".chip").forEach(c => {
    c.classList.toggle("active", c.dataset.val === val);
  });
}

["am-sport-chips", "am-gender-chips", "am-level-chips"].forEach(id => {
  $(id).addEventListener("click", e => {
    const chip = e.target.closest(".chip");
    if (!chip) return;
    $(id).querySelectorAll(".chip").forEach(c => c.classList.remove("active"));
    chip.classList.add("active");
  });
});

$("newAthleteBtn").addEventListener("click", () => openAthleteModal());
$("athleteModalClose").addEventListener("click",  () => closeModal("athleteModal"));
$("athleteModalCancel").addEventListener("click", () => closeModal("athleteModal"));
$("athleteModal").addEventListener("click", e => { if (e.target === $("athleteModal")) closeModal("athleteModal"); });

$("athleteModalSave").addEventListener("click", async () => {
  const name     = $("am-name").value.trim();
  const password = $("am-password").value;
  const confirm  = $("am-password-confirm").value;
  const isEdit   = !!aState.editingId;

  if (!name) { alert("Athlete name is required."); $("am-name").focus(); return; }

  // Password validation
  if (!isEdit && !password) {
    alert("Password is required to create an athlete account.");
    $("am-password").focus();
    return;
  }
  if (password && password.length < 4) {
    alert("Password must be at least 4 characters.");
    $("am-password").focus();
    return;
  }
  if (password && password !== confirm) {
    alert("Passwords do not match.");
    $("am-password-confirm").focus();
    return;
  }

  const payload = {
    name,
    birth_year: parseInt($("am-birth-year").value) || null,
    sport:      $("am-sport-chips").querySelector(".chip.active")?.dataset.val  || null,
    gender:     $("am-gender-chips").querySelector(".chip.active")?.dataset.val || null,
    level:      $("am-level-chips").querySelector(".chip.active")?.dataset.val  || null,
    position:   $("am-position").value.trim() || null,
    notes:      $("am-notes").value.trim()    || null,
  };
  if (!payload.sport)  delete payload.sport;
  if (!payload.gender) delete payload.gender;
  if (password)        payload.password = password;

  try {
    let result;
    if (isEdit) {
      result = await apiFetch("/api/athletes/" + aState.editingId, { method: "PUT", body: JSON.stringify(payload) });
    } else {
      result = await apiFetch("/api/athletes", { method: "POST", body: JSON.stringify(payload) });
    }
    closeModal("athleteModal");
    await loadAthletes();
    if (isEdit && aState.currentAthlete?.id === aState.editingId) {
      await openAthleteDetail(aState.editingId);
    } else if (!isEdit && result?.username) {
      // Show the generated username to the coach right after creating
      setTimeout(() => alert(`Athlete created!\nLogin username: ${result.username}\nPassword: set by you`), 100);
    }
  } catch (err) { alert("Error: " + err.message); }
});

async function deleteAthlete(aid) {
  const a = aState.athletes.find(x => x.id === aid);
  const aName = a ? a.name : "";
  $("confirmMsg").textContent = 'Delete athlete "' + aName + '"? Their programs and 1RM records will remain but be unlinked.';
  $("confirmModal").classList.remove("hidden");
  $("confirmYes").onclick = async () => {
    try {
      await apiFetch("/api/athletes/" + aid, { method: "DELETE" });
      closeModal("confirmModal");
      await loadAthletes();
    } catch (err) { alert("Error: " + err.message); }
  };
}

/* ── Athlete detail action buttons ───────────────────────────────────────── */
$("backToAthletesBtn").addEventListener("click", () => switchView("athletes"));

$("editAthleteBtn").addEventListener("click", () => {
  if (aState.currentAthlete) openAthleteModal(aState.currentAthlete.id);
});

$("athleteNewProgramBtn").addEventListener("click", () => {
  pState.contextAthleteId   = aState.currentAthlete?.id;
  pState.contextAthleteName = aState.currentAthlete?.name;
  openNewProgramModal();
});

$("athleteAddORMBtn").addEventListener("click", () => {
  ormState.athleteId = aState.currentAthlete?.id;
  openOneRMModal();
});

/* ═══════════════════════════════════════════════════════════════════════════
   TEAMS FEATURE
   ═══════════════════════════════════════════════════════════════════════════ */

/* ── Team state ───────────────────────────────────────────────────────────── */
const tState = {
  teams:       [],
  currentTeam: null,
  editingId:   null,
};

/* ── Helper functions ─────────────────────────────────────────────────────── */
function resetChips(containerId) {
  const chips = $(containerId).querySelectorAll(".chip");
  chips.forEach((c, i) => c.classList.toggle("active", i === 0));
}

function setChip(containerId, value) {
  $(containerId).querySelectorAll(".chip").forEach(c => {
    c.classList.toggle("active", c.dataset.val === value);
  });
}

/* ── Load & render teams ──────────────────────────────────────────────────── */
async function loadTeams() {
  tState.teams = await apiFetch("/api/teams");
  renderTeams();
}

function renderTeams() {
  const grid  = $("teamsGrid");
  const empty = $("teamsEmpty");
  grid.innerHTML = "";

  if (tState.teams.length === 0) {
    empty.classList.remove("hidden");
    return;
  }
  empty.classList.add("hidden");

  tState.teams.forEach(t => {
    const card = document.createElement("div");
    card.className = "athlete-card";
    const sc = sportColor(t.sport);
    const si = sportIcon(t.sport);
    const sportSpan = t.sport
      ? `<span style="color:${sc};font-weight:600;text-transform:capitalize">${esc(t.sport)}</span>`
      : `<span style="color:#6B7280">General</span>`;

    card.innerHTML = `
      <div class="athlete-card-sport-bar" style="background:${sc}"></div>
      <div class="athlete-card-body">
        <div class="athlete-card-header">
          <div class="athlete-card-avatar" style="background:${sc}22;color:${sc}">
            <i class="${si}"></i>
          </div>
          <div class="athlete-card-info">
            <div class="athlete-card-name">${esc(t.name)}</div>
            <div class="athlete-card-sub">${sportSpan}</div>
          </div>
        </div>
        <div class="athlete-card-stats">
          <div class="athlete-stat"><i class="fa-solid fa-users"></i> ${t.member_count || 0} athletes</div>
          <div class="athlete-stat"><i class="fa-solid fa-calendar-days"></i> ${t.program_count || 0} programs</div>
        </div>
        <div class="athlete-card-actions">
          <button class="btn-ghost btn-sm edit-team-btn" data-id="${t.id}"><i class="fa-solid fa-pen"></i></button>
          <button class="btn-danger btn-sm del-team-btn" data-id="${t.id}"><i class="fa-solid fa-trash"></i></button>
        </div>
      </div>
    `;
    card.addEventListener("click", e => {
      if (e.target.closest(".edit-team-btn")) { e.stopPropagation(); openTeamModal(t.id); return; }
      if (e.target.closest(".del-team-btn"))  { e.stopPropagation(); confirmDeleteTeam(t.id, t.name); return; }
      openTeamDetail(t.id);
    });
    grid.appendChild(card);
  });
}

/* ── Team detail ──────────────────────────────────────────────────────────── */
async function openTeamDetail(tid) {
  const team = await apiFetch("/api/teams/" + tid);
  tState.currentTeam = team;

  $("teamDetailName").textContent = team.name;
  const sportStr = team.sport ? team.sport.charAt(0).toUpperCase() + team.sport.slice(1) : "General";
  const memberStr = `${team.member_count || 0} athletes`;
  $("teamDetailMeta").textContent = `${sportStr} · ${memberStr}`;

  switchView("team-detail");
  renderTeamRoster(team.members || []);
  await loadTeamPrograms(tid);
}

function renderTeamRoster(members) {
  const grid  = $("teamRosterGrid");
  const empty = $("teamRosterEmpty");
  grid.innerHTML = "";

  if (!members.length) {
    empty.classList.remove("hidden");
    return;
  }
  empty.classList.add("hidden");

  members.forEach(a => {
    const card = document.createElement("div");
    card.className = "athlete-card";
    const sc = sportColor(a.sport);
    const si = sportIcon(a.sport);
    const sportSpan = a.sport
      ? `<span style="color:${sc};font-weight:600;text-transform:capitalize">${esc(a.sport)}</span>` : "";
    const posSpan = a.position ? `<span class="athlete-card-position">&middot; ${esc(a.position)}</span>` : "";
    const ls = levelStyle(a.level);
    const levelBadge = a.level
      ? `<div class="athlete-card-level" style="background:${ls.bg};color:${ls.text}">${esc(a.level)}</div>` : "";

    card.innerHTML = `
      <div class="athlete-card-sport-bar" style="background:${sc}"></div>
      <div class="athlete-card-body">
        <div class="athlete-card-header">
          <div class="athlete-card-avatar" style="background:${sc}22;color:${sc}">
            <i class="${si}"></i>
          </div>
          <div class="athlete-card-info">
            <div class="athlete-card-name">${esc(a.name)}</div>
            <div class="athlete-card-sub">${sportSpan}${posSpan}</div>
          </div>
          ${levelBadge}
        </div>
        <div class="athlete-card-actions" style="margin-top:10px">
          <button class="btn-danger btn-sm remove-member-btn" data-aid="${a.id}" title="Remove from team">
            <i class="fa-solid fa-user-minus"></i> Remove
          </button>
        </div>
      </div>
    `;
    card.querySelector(".remove-member-btn").addEventListener("click", e => {
      e.stopPropagation();
      confirmRemoveMember(a.id, a.name);
    });
    grid.appendChild(card);
  });
}

async function confirmRemoveMember(aid, name) {
  $("confirmMsg").textContent = `Remove ${name} from this team?`;
  $("confirmModal").classList.remove("hidden");
  $("confirmYes").onclick = async () => {
    try {
      await apiFetch(`/api/teams/${tState.currentTeam.id}/members/${aid}`, { method: "DELETE" });
      closeModal("confirmModal");
      const updated = await apiFetch("/api/teams/" + tState.currentTeam.id);
      tState.currentTeam = updated;
      renderTeamRoster(updated.members || []);
    } catch (err) { alert("Error: " + err.message); }
  };
}

async function loadTeamPrograms(tid) {
  const programs = await apiFetch("/api/teams/" + tid + "/programs");
  const grid  = $("teamProgramsGrid");
  const empty = $("teamProgramsEmpty");
  grid.innerHTML = "";

  if (!programs.length) {
    empty.classList.remove("hidden");
    return;
  }
  empty.classList.add("hidden");

  programs.forEach(p => {
    const card = document.createElement("div");
    card.className = "program-card";
    const goalCls = `goal-${p.goal}`;
    const phasesBar = (p.phases || []).map(ph =>
      `<div class="phase-bar-segment" style="background:${PHASE_COLORS[ph] || '#CBD5E1'}" title="${ph}"></div>`
    ).join("");
    const startLabel = p.start_date ? `<span>From ${esc(p.start_date)}</span>` : `<span>No start date</span>`;

    card.innerHTML = `
      <div class="program-card-name">${esc(p.name)}</div>
      <div class="program-card-meta">
        <span class="program-badge ${goalCls}">${esc(p.goal)}</span>
        <span class="program-badge">${p.duration_weeks}w · ${p.days_per_week}d/wk</span>
      </div>
      <div class="phase-bar">${phasesBar}</div>
      <div class="program-card-footer">
        ${startLabel}
        <div class="program-card-actions">
          <button class="btn-icon del-team-prog" title="Delete"><i class="fa-solid fa-trash"></i></button>
        </div>
      </div>
    `;
    card.addEventListener("click", e => {
      if (e.target.closest(".del-team-prog")) {
        e.stopPropagation();
        $("confirmMsg").textContent = `Delete program "${p.name}"?`;
        $("confirmModal").classList.remove("hidden");
        $("confirmYes").onclick = async () => {
          try {
            await apiFetch("/api/programs/" + p.id, { method: "DELETE" });
            closeModal("confirmModal");
            await loadTeamPrograms(tState.currentTeam.id);
          } catch (err) { alert("Error: " + err.message); }
        };
        return;
      }
      pState.fromTeamId = tState.currentTeam?.id;
      switchView("programs");
      openProgramEditor(p.id);
    });
    grid.appendChild(card);
  });
}

/* ── Team modal ───────────────────────────────────────────────────────────── */
async function openTeamModal(teamId) {
  tState.editingId = teamId || null;
  const isEdit = !!teamId;
  $("teamModalTitle").textContent = isEdit ? "Edit Team" : "New Team";
  $("tm-name").value  = "";
  $("tm-notes").value = "";
  resetChips("tm-sport-chips");

  if (isEdit) {
    const t = tState.teams.find(x => x.id === teamId) || await apiFetch("/api/teams/" + teamId);
    $("tm-name").value  = t.name  || "";
    $("tm-notes").value = t.notes || "";
    setChip("tm-sport-chips", t.sport || "");
  }

  $("teamModal").classList.remove("hidden");
  $("tm-name").focus();
}

$("newTeamBtn").addEventListener("click", () => openTeamModal());
$("teamModalClose").addEventListener("click",  () => closeModal("teamModal"));
$("teamModalCancel").addEventListener("click", () => closeModal("teamModal"));
$("teamModal").addEventListener("click", e => { if (e.target === $("teamModal")) closeModal("teamModal"); });

$("tm-sport-chips").addEventListener("click", e => {
  const chip = e.target.closest(".chip");
  if (!chip) return;
  $("tm-sport-chips").querySelectorAll(".chip").forEach(c => c.classList.remove("active"));
  chip.classList.add("active");
});

$("teamModalSave").addEventListener("click", async () => {
  const name = $("tm-name").value.trim();
  if (!name) { alert("Team name is required."); $("tm-name").focus(); return; }
  const payload = {
    name,
    sport: $("tm-sport-chips").querySelector(".chip.active")?.dataset.val || null,
    notes: $("tm-notes").value.trim() || null,
  };
  if (!payload.sport) payload.sport = null;
  try {
    if (tState.editingId) {
      await apiFetch("/api/teams/" + tState.editingId, { method: "PUT", body: JSON.stringify(payload) });
    } else {
      await apiFetch("/api/teams", { method: "POST", body: JSON.stringify(payload) });
    }
    closeModal("teamModal");
    await loadTeams();
    if (tState.editingId && tState.currentTeam?.id === tState.editingId) {
      await openTeamDetail(tState.editingId);
    }
  } catch (err) { alert("Error: " + err.message); }
});

async function confirmDeleteTeam(tid, name) {
  $("confirmMsg").textContent = `Delete team "${name}"? Athletes and programs will not be deleted.`;
  $("confirmModal").classList.remove("hidden");
  $("confirmYes").onclick = async () => {
    try {
      await apiFetch("/api/teams/" + tid, { method: "DELETE" });
      closeModal("confirmModal");
      await loadTeams();
    } catch (err) { alert("Error: " + err.message); }
  };
}

/* ── Add member modal ─────────────────────────────────────────────────────── */
$("backToTeamsBtn").addEventListener("click", () => switchView("teams"));
$("editTeamBtn").addEventListener("click",    () => { if (tState.currentTeam) openTeamModal(tState.currentTeam.id); });

$("teamNewProgramBtn").addEventListener("click", () => {
  pState.contextTeamId   = tState.currentTeam?.id;
  pState.contextTeamName = tState.currentTeam?.name;
  pState.contextAthleteId   = null;
  pState.contextAthleteName = null;
  openNewProgramModal();
});

$("addMemberBtn").addEventListener("click", async () => {
  const athletes = await apiFetch("/api/athletes");
  const teamMemberIds = new Set((tState.currentTeam?.members || []).map(m => m.id));
  const available = athletes.filter(a => !teamMemberIds.has(a.id));

  const sel = $("member-athlete-select");
  sel.innerHTML = '<option value="">— Select an athlete —</option>';
  available.forEach(a => {
    const opt = document.createElement("option");
    opt.value = a.id;
    opt.textContent = a.name + (a.sport ? ` (${a.sport})` : "");
    sel.appendChild(opt);
  });

  $("addMemberModal").classList.remove("hidden");
});

$("addMemberModalClose").addEventListener("click",  () => closeModal("addMemberModal"));
$("addMemberModalCancel").addEventListener("click", () => closeModal("addMemberModal"));
$("addMemberModal").addEventListener("click", e => { if (e.target === $("addMemberModal")) closeModal("addMemberModal"); });

$("addMemberModalSave").addEventListener("click", async () => {
  const aid = parseInt($("member-athlete-select").value);
  if (!aid) { alert("Please select an athlete."); return; }
  try {
    await apiFetch(`/api/teams/${tState.currentTeam.id}/members`, {
      method: "POST",
      body: JSON.stringify({ athlete_id: aid }),
    });
    closeModal("addMemberModal");
    const updated = await apiFetch("/api/teams/" + tState.currentTeam.id);
    tState.currentTeam = updated;
    $("teamDetailMeta").textContent = `${updated.sport ? updated.sport.charAt(0).toUpperCase() + updated.sport.slice(1) : "General"} · ${updated.member_count || 0} athletes`;
    renderTeamRoster(updated.members || []);
  } catch (err) { alert("Error: " + err.message); }
});
